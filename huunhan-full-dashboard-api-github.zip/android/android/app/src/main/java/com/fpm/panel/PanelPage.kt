package com.fpm.panel

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import org.json.JSONObject

/** Mục 1: PANEL — giữ nguyên toàn bộ chức năng điều khiển Panel cũ, giao diện Premium. */
class PanelPage(private val a: HomeActivity) {
    private val c = a.cfg
    private lateinit var statusTv: TextView
    private lateinit var countTv: TextView
    private lateinit var netTv: TextView
    val view: View

    private val green = Color.rgb(46, 229, 157)

    init { view = build() }

    private fun displayName(): String {
        return try { JSONObject(a.st.profileRaw() ?: "{}").optJSONObject("profile")?.optString("displayName").orEmpty() } catch (e: Exception) { "" }
    }

    private fun build(): View {
        val scroll = ScrollView(a).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(20), a.dp(36), a.dp(20), a.dp(16)) }
        scroll.addView(col)

        // ---- HEADER: logo Panel + tên Panel do Admin thiết lập ----
        val head = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL }
        val logoFrame = FrameLayout(a).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(withAlpha(NEON_PURPLE, 0.35f), withAlpha(NEON_CYAN, 0.25f))).apply { shape = GradientDrawable.OVAL; setStroke(a.dp(2), c.primary) }
            setPadding(a.dp(5), a.dp(5), a.dp(5), a.dp(5))
        }
        val logo = ImageView(a).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        circleClip(logo)
        logoFrame.addView(logo, FrameLayout.LayoutParams(a.dp(54), a.dp(54)))
        Images.load(c.panelLogoUrl, logo, R.drawable.logo_panel)
        head.addView(logoFrame, LinearLayout.LayoutParams(a.dp(66), a.dp(66)))
        val brand = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(12), 0, 0, 0) }
        brand.addView(label(a, c.panelTitle.ifBlank { c.appName }, 19f, c.text, true))
        if (c.brandName.isNotBlank()) brand.addView(label(a, c.brandName, 11f, withAlpha(c.text, 0.7f)).apply { setPadding(0, a.dp(3), 0, 0) })
        brand.addView(label(a, c.subtitle, 9f, c.primary, true).apply { setPadding(0, a.dp(5), 0, 0); letterSpacing = 0.12f })
        head.addView(brand, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        head.addView(label(a, "● LIVE", 10f, green, true, true).apply { background = roundedBg(withAlpha(green, 0.12f), a.dp(20).toFloat()); setPadding(a.dp(12), a.dp(8), a.dp(12), a.dp(8)) })
        col.addView(head); head.fadeIn()
        col.addGap(a, 22)

        val name = displayName()
        col.addView(label(a, if (name.isBlank()) "Xin chào!" else "Xin chào, $name!", 23f, c.text, true))
        col.addGap(a, 5)
        col.addView(label(a, "Quản lý và điều khiển hệ thống panel của bạn.", 12f, withAlpha(c.text, 0.65f)))
        col.addGap(a, 18)

        // ---- Giới thiệu Panel (do Admin chỉnh) ----
        if (c.panelIntro.isNotBlank() || c.featureDesc.isNotBlank() || c.versionInfo.isNotBlank() || c.extraContent.isNotBlank()) {
            val intro = card(a, c).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(withAlpha(NEON_PURPLE, 0.22f), withAlpha(c.surface, 0.95f))).apply { cornerRadius = a.dp(20).toFloat(); setStroke(a.dp(1), withAlpha(NEON_PURPLE, 0.55f)) }
            }
            intro.addView(label(a, "✦  " + c.introTitle.ifBlank { "Giới thiệu" }.uppercase(), 12f, c.primary, true))
            if (c.panelIntro.isNotBlank()) { intro.addGap(a, 8); intro.addView(label(a, c.panelIntro, 12f, c.text)) }
            if (c.featureDesc.isNotBlank()) { intro.addGap(a, 8); intro.addView(label(a, c.featureDesc, 11f, withAlpha(c.text, 0.75f))) }
            if (c.extraContent.isNotBlank()) { intro.addGap(a, 8); intro.addView(label(a, c.extraContent, 11f, withAlpha(c.text, 0.75f))) }
            if (c.versionInfo.isNotBlank()) { intro.addGap(a, 10); intro.addView(label(a, c.versionInfo, 10f, c.primary, true).apply { background = roundedBg(withAlpha(c.primary, 0.12f), a.dp(14).toFloat()); setPadding(a.dp(10), a.dp(5), a.dp(10), a.dp(5)) }) }
            col.addView(intro, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)); intro.fadeIn(60)
            col.addGap(a, 16)
        }

        if (c.showBanner && c.bannerEnabled && c.bannerUrl.isNotBlank()) {
            val bannerBox = LinearLayout(a).apply { background = roundedBg(c.surface, a.dp(17).toFloat(), withAlpha(c.primary, 0.25f), a.dp(1)); clipToOutline = true }
            val banner = ImageView(a).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.CENTER_CROP }
            Images.load(c.bannerUrl, banner, null)
            bannerBox.addView(banner, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            col.addView(bannerBox, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)); col.addGap(a, 15)
        }
        if (c.showAnnouncement && c.announcement.isNotBlank()) {
            val notice = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBg(withAlpha(c.primary, 0.10f), a.dp(14).toFloat(), withAlpha(c.primary, 0.35f), a.dp(1))
                setPadding(a.dp(14), a.dp(13), a.dp(14), a.dp(13))
            }
            notice.addView(label(a, "📢  THÔNG BÁO", 11f, c.primary, true)); notice.addGap(a, 7); notice.addView(label(a, c.announcement, 12f, c.text))
            col.addView(notice); col.addGap(a, 18)
        }

        // ---- THÔNG TIN KEY ----
        val keyCard = card(a, c).apply { background = roundedBg(c.surface, a.dp(22).toFloat(), withAlpha(c.primary, 0.55f), a.dp(1)) }
        val kh = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL }
        kh.addView(label(a, "◈  THÔNG TIN KEY", 13f, c.text, true), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        kh.addView(label(a, "● ACTIVE", 10f, green, true, true).apply { background = roundedBg(withAlpha(green, 0.12f), a.dp(20).toFloat()); setPadding(a.dp(10), a.dp(7), a.dp(10), a.dp(7)) })
        keyCard.addView(kh); keyCard.addGap(a, 18)
        keyCard.addView(label(a, "THỜI GIAN SỬ DỤNG CÒN LẠI", 10f, withAlpha(c.text, 0.55f), true, true))
        keyCard.addGap(a, 4)
        countTv = label(a, "--:--:--", 30f, c.primary, true, true)
        keyCard.addView(countTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        keyCard.addGap(a, 14)
        keyCard.addView(View(a).apply { setBackgroundColor(withAlpha(c.text, 0.12f)) }, LinearLayout.LayoutParams(MATCH_PARENT, a.dp(1)))
        keyCard.addGap(a, 12)
        statusTv = label(a, "", 13f, green, true); keyCard.addView(statusTv); keyCard.addGap(a, 10)
        addInfo(keyCard, "Ngày kích hoạt", fmtDate(a.st.activatedAt.takeIf { it > 0 }))
        addInfo(keyCard, "Ngày hết hạn", if (a.st.lifetime) "Vĩnh viễn" else fmtDate(a.st.expiresAt.takeIf { it > 0 }))
        addInfo(keyCard, "Gói KEY", a.st.plan)
        col.addView(keyCard, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)); keyCard.fadeIn(120)
        col.addGap(a, 22)

        // ---- ĐIỀU KHIỂN PANEL (giữ nguyên chức năng cũ) ----
        col.addView(label(a, "ĐIỀU KHIỂN PANEL", 13f, c.text, true)); col.addGap(a, 12)
        addAction(col, "▶", "KHỞI ĐỘNG PANEL", "Bắt đầu hiển thị cửa sổ nổi", c.button, c.text, true) { a.startPanel() }
        addAction(col, "■", "DỪNG PANEL", "Tắt cửa sổ nổi đang hoạt động", withAlpha(0xFFFF5470.toInt(), 0.16f), 0xFFFF7185.toInt()) { a.stopPanel() }
        addAction(col, "⟳", "LÀM MỚI / ĐỒNG BỘ", "Kiểm tra trạng thái và cập nhật dữ liệu", withAlpha(c.primary, 0.15f), c.primary) { a.syncNow(); a.refreshConfig(true) }
        if (c.showSettings) addAction(col, "⚙", "CÀI ĐẶT GIAO DIỆN", "Tùy chỉnh kích thước và màu sắc panel", withAlpha(c.text, 0.09f), c.text) { a.openSettings() }
        col.addGap(a, 8)

        if (c.showServerStatus) {
            val sc = card(a, c).apply { background = roundedBg(withAlpha(c.surface, 0.90f), a.dp(16).toFloat(), withAlpha(c.text, 0.10f), a.dp(1)) }
            sc.addView(label(a, "SERVER CONNECTION", 10f, withAlpha(c.text, 0.55f), true)); sc.addGap(a, 8)
            netTv = label(a, "● Đang kết nối...", 12f, c.text, true); sc.addView(netTv)
            col.addView(sc)
        } else netTv = TextView(a)
        col.addGap(a, 16)
        col.addView(label(a, "${c.appName}  •  PREMIUM SYSTEM", 10f, withAlpha(c.text, 0.4f), true, true))
        updateCountdown(); updateNet()
        return scroll
    }

    private fun addInfo(parent: LinearLayout, title: String, value: String) {
        val row = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, a.dp(5), 0, a.dp(5)) }
        row.addView(label(a, title, 11f, withAlpha(c.text, 0.58f)), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(label(a, value, 11f, c.text, true)); parent.addView(row)
    }

    private fun addAction(parent: LinearLayout, icon: String, title: String, desc: String, fill: Int, textColor: Int, gradient: Boolean = false, action: () -> Unit) {
        val item = LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(a.dp(14), a.dp(13), a.dp(14), a.dp(13))
            background = if (gradient) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(NEON_PURPLE, withAlpha(NEON_CYAN, 0.85f))).apply { cornerRadius = a.dp(16).toFloat() }
            else roundedBg(fill, a.dp(16).toFloat(), withAlpha(textColor, 0.20f), a.dp(1))
            isClickable = true; isFocusable = true; setOnClickListener { action() }; press()
        }
        item.addView(label(a, icon, 20f, textColor, true, true).apply { background = roundedBg(withAlpha(if (gradient) Color.WHITE else textColor, 0.14f), a.dp(12).toFloat()) }, LinearLayout.LayoutParams(a.dp(43), a.dp(43)))
        val tb = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(12), 0, 0, 0) }
        tb.addView(label(a, title, 12f, textColor, true)); tb.addGap(a, 5); tb.addView(label(a, desc, 10f, withAlpha(c.text, 0.65f)))
        item.addView(tb, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        item.addView(label(a, "›", 23f, withAlpha(textColor, 0.7f), true))
        parent.addView(item, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)); parent.addGap(a, 10)
    }

    fun updateNet() {
        netTv.text = when (a.online) { true -> "● Đã kết nối Server"; false -> "● Mất kết nối Server (chế độ tạm thời)"; null -> "● Đang kết nối..." }
        netTv.setTextColor(when (a.online) { true -> 0xFF2EE59D.toInt(); false -> 0xFFFFB020.toInt(); null -> 0xFF8B96B5.toInt() })
    }

    fun updateCountdown() {
        val rem = a.st.remainingMs(); val expired = rem != null && rem <= 0
        statusTv.text = if (expired) "●  KEY ĐÃ HẾT HẠN" else "●  KEY ĐANG HOẠT ĐỘNG"
        statusTv.setTextColor(if (expired) 0xFFFF5470.toInt() else 0xFF2EE59D.toInt())
        countTv.text = when { a.st.lifetime -> "∞ VĨNH VIỄN"; rem == null -> "--:--:--"; else -> fmtRemaining(rem) }
    }
}
