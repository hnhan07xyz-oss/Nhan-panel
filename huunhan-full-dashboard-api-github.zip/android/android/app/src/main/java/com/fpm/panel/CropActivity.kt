package com.fpm.panel

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import java.io.File

/** Vùng cắt ảnh: khung tròn, kéo để di chuyển, hai ngón hoặc thanh trượt để phóng to / thu nhỏ. */
class CropView(ctx: Context, private val bmp: Bitmap, private val onChange: () -> Unit) : View(ctx) {
    private var scale = 1f; private var minScale = 1f
    private var tx = 0f; private var ty = 0f
    private var cx = 0f; private var cy = 0f; private var r = 0f
    private var lx = 0f; private var ly = 0f
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val dim = Paint().apply { color = 0xCC06050F.toInt() }
    private val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(2).toFloat(); color = NEON_CYAN }
    private val m = Matrix()
    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { zoomBy(d.scaleFactor, d.focusX, d.focusY); return true }
    })

    /** 1.0 = vừa khung, tối đa 4.0 */
    val zoomLevel: Float get() = scale / minScale

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f; cy = h / 2f; r = minOf(w, h) * 0.42f
        minScale = maxOf(2 * r / bmp.width, 2 * r / bmp.height)
        scale = minScale; tx = cx - bmp.width * scale / 2; ty = cy - bmp.height * scale / 2
        clamp(); onChange()
    }
    private fun clamp() {
        val bw = bmp.width * scale; val bh = bmp.height * scale
        tx = tx.coerceIn(cx + r - bw, cx - r); ty = ty.coerceIn(cy + r - bh, cy - r)
    }
    private fun zoomBy(f: Float, fx: Float, fy: Float) {
        val ns = (scale * f).coerceIn(minScale, minScale * 4); val k = ns / scale
        tx = fx - (fx - tx) * k; ty = fy - (fy - ty) * k; scale = ns; clamp(); invalidate(); onChange()
    }
    fun setZoom(level: Float) { zoomBy((minScale * level) / scale, cx, cy) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        scaler.onTouchEvent(e)
        if (!scaler.isInProgress) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
                MotionEvent.ACTION_MOVE -> if (e.pointerCount == 1) { tx += e.x - lx; ty += e.y - ly; lx = e.x; ly = e.y; clamp(); invalidate(); onChange() }
                MotionEvent.ACTION_POINTER_UP -> { val i = if (e.actionIndex == 0) 1 else 0; lx = e.getX(i); ly = e.getY(i) }
            }
        } else { lx = e.x; ly = e.y }
        return true
    }
    override fun onDraw(c: Canvas) {
        m.reset(); m.postScale(scale, scale); m.postTranslate(tx, ty)
        c.drawBitmap(bmp, m, bmpPaint)
        val sc = c.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim); c.drawCircle(cx, cy, r, hole)
        c.restoreToCount(sc)
        c.drawCircle(cx, cy, r, ring)
    }
    /** Xuất ảnh vuông out×out, phần ngoài hình tròn trong suốt. */
    fun render(out: Int): Bitmap {
        val o = Bitmap.createBitmap(out, out, Bitmap.Config.ARGB_8888); val c = Canvas(o)
        c.clipPath(Path().apply { addCircle(out / 2f, out / 2f, out / 2f, Path.Direction.CW) })
        val mm = Matrix(); mm.postScale(scale, scale); mm.postTranslate(tx - (cx - r), ty - (cy - r)); mm.postScale(out / (2 * r), out / (2 * r))
        c.drawBitmap(bmp, mm, Paint(Paint.FILTER_BITMAP_FLAG)); return o
    }
}

/** Màn hình cắt ảnh hình tròn dùng cho ảnh đại diện. Trả về đường dẫn file PNG trong "path". */
class CropActivity : Activity() {
    private lateinit var cropView: CropView
    private lateinit var preview: ImageView
    private lateinit var zoom: SeekBar

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val uri = intent.data
        val bmp = if (uri != null) loadBitmap(uri) else null
        if (bmp == null) { Toast.makeText(this, "Không đọc được ảnh", Toast.LENGTH_SHORT).show(); setResult(RESULT_CANCELED); finish(); return }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawableCompat.bg()
            setPadding(dp(16), dp(34), dp(16), dp(18))
        }
        root.addView(label(this, "CẮT ẢNH HÌNH TRÒN", 17f, NEON_CYAN, true, true))
        root.addView(label(this, "Kéo để di chuyển • Hai ngón hoặc thanh trượt để phóng to / thu nhỏ", 11f, withAlpha(Color.WHITE, 0.6f), false, true).apply { setPadding(0, dp(6), 0, dp(10)) })

        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        cropView = CropView(this, bmp) { updatePreview() }
        root.addView(cropView, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        val zr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(4)) }
        zr.addView(label(this, "➖", 16f, Color.WHITE))
        zoom = SeekBar(this).apply {
            max = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) cropView.setZoom(1f + p / 100f * 3f) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        zr.addView(zoom, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)); zr.addView(label(this, "➕", 16f, Color.WHITE))
        root.addView(zr)

        val pr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val pf = FrameLayout(this).apply { background = roundedBg(Color.TRANSPARENT, dp(44).toFloat(), NEON_PURPLE, dp(2)); setPadding(dp(3), dp(3), dp(3), dp(3)) }
        circleClip(preview); pf.addView(preview, FrameLayout.LayoutParams(dp(78), dp(78)))
        pr.addView(pf, LinearLayout.LayoutParams(dp(88), dp(88)))
        pr.addView(label(this, "Xem trước", 12f, withAlpha(Color.WHITE, 0.7f)).apply { setPadding(dp(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        root.addView(pr)
        root.addGap(this, 12)

        val br = LinearLayout(this)
        br.addView(button(this, "HỦY", withAlpha(Color.WHITE, 0.08f), Color.WHITE) { setResult(RESULT_CANCELED); finish() }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { rightMargin = dp(8) })
        br.addView(gradButton(this, "XÁC NHẬN", NEON_PURPLE, NEON_CYAN, Color.WHITE) { confirm() }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        root.addView(br)
        setContentView(root)
    }

    private fun updatePreview() {
        if (!::preview.isInitialized) return
        preview.setImageBitmap(cropView.render(160))
        val p = ((cropView.zoomLevel - 1f) / 3f * 100f).toInt().coerceIn(0, 100)
        if (::zoom.isInitialized && zoom.progress != p) zoom.progress = p
    }
    private fun confirm() {
        try {
            val out = cropView.render(512)
            val f = File(cacheDir, "crop_${System.currentTimeMillis()}.png")
            f.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            setResult(RESULT_OK, Intent().putExtra("path", f.absolutePath)); finish()
        } catch (e: Exception) { Toast.makeText(this, "Không lưu được ảnh", Toast.LENGTH_SHORT).show() }
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var s = 1; while (bounds.outWidth / s > 2048 || bounds.outHeight / s > 2048) s *= 2
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) } ?: return null
            val orient = try { contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) } } catch (e: Exception) { null }
            val deg = when (orient) { ExifInterface.ORIENTATION_ROTATE_90 -> 90f; ExifInterface.ORIENTATION_ROTATE_180 -> 180f; ExifInterface.ORIENTATION_ROTATE_270 -> 270f; else -> 0f }
            if (deg == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        } catch (e: Exception) { null }
    }
}

/** Nền gradient tối dùng chung. */
object GradientDrawableCompat {
    fun bg() = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(6, 5, 15), Color.rgb(16, 10, 38), Color.rgb(8, 12, 30)))
}
