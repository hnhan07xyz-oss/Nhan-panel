package com.fpm.panel

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Chỉ gọi các endpoint công khai /api/v1. Không có secret hay API quản trị trong APK. */
object Api {
    class Res(val code: Int, val json: JSONObject, val net: Boolean) { val ok get() = code in 200..299 && json.optBoolean("ok", true) }

    private fun call(method: String, path: String, body: JSONObject?, bearer: String?, device: String? = null): Res {
        var c: HttpURLConnection? = null
        return try {
            c = URL(BuildConfig.SERVER_URL + "/api/v1" + path).openConnection() as HttpURLConnection
            c.requestMethod = method; c.connectTimeout = 8000; c.readTimeout = 10000
            c.setRequestProperty("Accept", "application/json")
            bearer?.let { c.setRequestProperty("Authorization", "Bearer $it") }
            device?.let { c.setRequestProperty("X-Device-Id", it) }
            if (body != null) {
                c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
            Res(code, try { JSONObject(txt) } catch (e: Exception) { JSONObject() }, false)
        } catch (e: Exception) { Res(0, JSONObject(), true) } finally { c?.disconnect() }
    }

    suspend fun config(): AppConfig? = withContext(Dispatchers.IO) {
        val r = call("GET", "/config", null, null); if (r.code == 200) AppConfig(r.json) else null
    }
    suspend fun activate(key: String, deviceId: String, model: String) = withContext(Dispatchers.IO) {
        call("POST", "/keys/activate", JSONObject().put("key", key).put("deviceId", deviceId).put("model", model), null)
    }
    suspend fun status(session: String, deviceId: String) = withContext(Dispatchers.IO) {
        call("POST", "/keys/status", JSONObject().put("deviceId", deviceId), session)
    }

    suspend fun panel(session: String, deviceId: String) = withContext(Dispatchers.IO) { call("GET", "/panel", null, session, deviceId) }
    suspend fun toggle(session: String, deviceId: String, id: Int, on: Boolean) = withContext(Dispatchers.IO) {
        call("POST", "/panel/features/$id/toggle", JSONObject().put("on", on), session, deviceId)
    }
    suspend fun run(session: String, deviceId: String, id: Int) = withContext(Dispatchers.IO) {
        call("POST", "/panel/features/$id/run", JSONObject(), session, deviceId)
    }

    suspend fun boxes(session: String, deviceId: String) = withContext(Dispatchers.IO) { call("GET", "/panel/boxes", null, session, deviceId) }
    suspend fun profile(session: String, deviceId: String) = withContext(Dispatchers.IO) { call("GET", "/panel/profile", null, session, deviceId) }
    suspend fun saveProfile(session: String, deviceId: String, body: JSONObject) = withContext(Dispatchers.IO) { call("PUT", "/panel/profile", body, session, deviceId) }

    /** Tải ảnh đại diện (PNG đã cắt tròn) lên Server. Chỉ ghi vào hồ sơ của chính phiên đăng nhập này. */
    suspend fun uploadAvatar(session: String, deviceId: String, png: ByteArray): Res = withContext(Dispatchers.IO) {
        var c: HttpURLConnection? = null
        try {
            c = URL(BuildConfig.SERVER_URL + "/api/v1/panel/profile/avatar").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 30000; c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer $session"); c.setRequestProperty("X-Device-Id", deviceId)
            c.setRequestProperty("Content-Type", "image/png"); c.setFixedLengthStreamingMode(png.size)
            c.outputStream.use { it.write(png) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
            Res(code, try { JSONObject(txt) } catch (e: Exception) { JSONObject() }, false)
        } catch (e: Exception) { Res(0, JSONObject(), true) } finally { c?.disconnect() }
    }
}
