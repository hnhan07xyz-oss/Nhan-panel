package com.fpm.panel

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.File

/**
 * Giao diện chính sau khi nhập KEY: thanh điều hướng dưới cùng 3 mục
 * PANEL • BOX SHARE KEY • PROFILE. Toàn bộ logic KEY / đồng bộ / panel nổi giữ nguyên như bản cũ.
 */
class HomeActivity : Activity() {

    val scope = MainScope()
    private val handler = Handler(Looper.getMainLooper())

    lateinit var st: Store
    var cfg = AppConfig.default()
    var online: Boolean? = null
    private var lastSync = 0L
    private var current = 0

    private var host: FrameLayout? = null
    private var panelPage: PanelPage? = null
    private var boxPage: BoxPage? = null
    private var profilePage: ProfilePage? = null
    private class NavItem(val root: LinearLayout, val icon: NavIcon, val text: TextView)
    private val navItems = ArrayList<NavItem>()

    companion object { private const val RC_PICK = 7001; private const val RC_CROP = 7002 }

    private val tick = object : Runnable {
        override fun run() {
            if (!::st.isInitialized) return
            val rem = st.remainingMs()
            if (rem != null && rem <= 0) { Session.lockAndExit(this@HomeActivity, cfg.expiredMessage); return }
            panelPage?.updateCountdown()
            if (System.currentTimeMillis() - lastSync > 60_000) syncNow()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = Store.get(this); cfg = st.config()
        if (st.session == null) { startActivity(Intent(this, KeyActivity::class.java)); finish(); return }
        build()
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        if (::st.isInitialized && st.session != null) { handler.removeCallbacks(tick); handler.post(tick); refreshConfig() }
    }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }
    override fun onDestroy() { super.onDestroy(); handler.removeCallbacks(tick); scope.cancel() }

    // ===================== KHUNG GIAO DIỆN + THANH ĐIỀU HƯỚNG =====================
    private fun build() {
        val c = cfg
        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(darker(c.background, 0.55f), c.background, Color.rgb(18, 10, 40)))
        }
        val bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.14f }
        root.addView(bg, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        Images.load(c.backgroundUrl, bg, null)

        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val h = FrameLayout(this); host = h
        column.addView(h, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        column.addView(buildNav(c), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { setMargins(dp(14), dp(4), dp(14), dp(14)) })
        root.addView(column, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(root)

        panelPage = PanelPage(this); boxPage = BoxPage(this); profilePage = ProfilePage(this)
        select(current, false)
    }

    private fun buildNav(c: AppConfig): View {
        navItems.clear()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(8), dp(8), dp(8)); elevation = dp(10).toFloat()
            background = GradientDrawable().apply { setColor(withAlpha(Color.rgb(14, 10, 32), 0.97f)); cornerRadius = dp(28).toFloat(); setStroke(dp(1), withAlpha(NEON_PURPLE, 0.55f)) }
        }
        val items = listOf("PANEL" to 0, "BOX SHARE KEY" to 1, "PROFILE" to 2)
        items.forEach { (title, idx) ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(8), dp(4), dp(8)); isClickable = true; press() }
            val icon = NavIcon(this, idx)
            val tv = label(this, title, 9f, Color.GRAY, true, true).apply { setPadding(0, dp(4), 0, 0); letterSpacing = 0.05f; maxLines = 1 }
            item.addView(icon, LinearLayout.LayoutParams(dp(26), dp(26)))
            item.addView(tv, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
            item.setOnClickListener { if (idx != current) select(idx, true) }
            bar.addView(item, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            navItems.add(NavItem(item, icon, tv))
        }
        return bar
    }

    private fun pageView(i: Int): View? = when (i) { 0 -> panelPage?.view; 1 -> boxPage?.view; else -> profilePage?.view }

    private fun styleNav(sel: Int) {
        navItems.forEachIndexed { i, n ->
            val on = i == sel
            n.icon.tint = if (on) NEON_CYAN else Color.rgb(125, 118, 160)
            n.text.setTextColor(if (on) Color.WHITE else Color.rgb(125, 118, 160))
            n.root.background = if (on) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(withAlpha(NEON_PURPLE, 0.45f), withAlpha(NEON_CYAN, 0.22f))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), withAlpha(NEON_CYAN, 0.45f)) } else null
            n.root.animate().scaleX(if (on) 1.04f else 1f).scaleY(if (on) 1.04f else 1f).setDuration(160).start()
        }
    }

    private fun select(i: Int, animate: Boolean) {
        val h = host ?: return; val page = pageView(i) ?: return
        val dir = if (i >= current) 1f else -1f
        styleNav(i); current = i
        val old = if (h.childCount > 0) h.getChildAt(0) else null
        if (old === page) return
        if (animate && old != null) {
            old.animate().alpha(0f).translationX(-26f * dir).setDuration(130).withEndAction {
                h.removeAllViews(); old.alpha = 1f; old.translationX = 0f
                page.alpha = 0f; page.translationX = 30f * dir; h.addView(page)
                page.animate().alpha(1f).translationX(0f).setDuration(220).start()
            }.start()
        } else { h.removeAllViews(); page.alpha = 1f; page.translationX = 0f; h.addView(page) }
        when (i) { 1 -> boxPage?.onShow(); 2 -> profilePage?.onShow() }
    }

    // ===================== LOGIC CŨ (giữ nguyên) =====================
    fun syncNow() {
        lastSync = System.currentTimeMillis()
        scope.launch {
            when (val s = Session.sync(this@HomeActivity)) {
                is Sync.Ok -> { online = true; panelPage?.updateNet(); panelPage?.updateCountdown() }
                is Sync.Offline -> {
                    online = false; panelPage?.updateNet()
                    if (!st.canUseOffline(this@HomeActivity)) Session.lockAndExit(this@HomeActivity, "Cần kết nối Internet để xác thực KEY")
                }
                is Sync.Locked -> Session.lockAndExit(this@HomeActivity, if (s.status == "EXPIRED") cfg.expiredMessage else s.msg)
            }
        }
    }

    fun refreshConfig(manual: Boolean = false) = scope.launch {
        val n = Api.config() ?: run { if (manual) toast("Không tải được cấu hình"); return@launch }
        if (n.stamp != cfg.stamp) {
            st.saveConfig(n); cfg = n; build()
            if (FloatingService.running) startService(Intent(this@HomeActivity, FloatingService::class.java).setAction(FloatingService.ACTION_REFRESH))
        }
        if (manual) toast("Đã đồng bộ")
    }

    fun logoutKey() {
        AlertDialog.Builder(this).setTitle("Đăng xuất KEY")
            .setMessage("Panel sẽ đóng và bạn quay về màn nhập KEY để dùng KEY khác. KEY hiện tại vẫn gắn với máy này.")
            .setPositiveButton("Đăng xuất") { _, _ ->
                stopService(Intent(this, FloatingService::class.java)); st.clearSession()
                startActivity(Intent(this, KeyActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            }.setNegativeButton("Hủy", null).show()
    }

    fun toast(t: String) { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }
    fun openSettings() { startActivity(Intent(this, SettingsActivity::class.java)) }
    fun stopPanel() { stopService(Intent(this, FloatingService::class.java)); toast("Đã dừng panel") }

    fun startPanel() {
        val rem = st.remainingMs()
        if (rem != null && rem <= 0) { Session.lockAndExit(this, cfg.expiredMessage); return }
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this).setTitle("Cấp quyền cửa sổ nổi")
                .setMessage("Để hiển thị panel trên các ứng dụng khác, hãy bật \"Hiển thị trên các ứng dụng khác\" cho ứng dụng này.")
                .setPositiveButton("Mở cài đặt") { _, _ -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
                .setNegativeButton("Hủy", null).show()
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, FloatingService::class.java))
        toast("Đã khởi động panel")
    }

    // ===================== CHỌN + CẮT ẢNH ĐẠI DIỆN =====================
    fun pickAvatar() {
        try {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }, RC_PICK)
        } catch (e: Exception) { toast("Không mở được thư viện ảnh") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            RC_PICK -> data?.data?.let { startActivityForResult(Intent(this, CropActivity::class.java).setData(it), RC_CROP) }
            RC_CROP -> data?.getStringExtra("path")?.let { profilePage?.uploadAvatar(File(it)) }
        }
    }
}
