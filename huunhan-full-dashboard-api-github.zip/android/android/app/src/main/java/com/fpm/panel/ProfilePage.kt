package com.fpm.panel

import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File

/** Mục 3: PROFILE — hồ sơ cá nhân của chính chủ tài khoản (lưu trên Server theo từng tài khoản). */
class ProfilePage(private val a: HomeActivity) {
    private class P(val displayName: String, val username: String, val bio: String, val contact: String, val socialUrl: String, val avatarUrl: String, val joinedAt: Long, val role: String, val plan: String)

    private val c = a.cfg
    private val body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private val spinner = SpinnerView(a)
    private val msg = label(a, "", 12f, 0xFFFFB020.toInt(), false, true)
    private var profile: P? = null
    private var busyUpload = false
    val view: View

    init {
        val scroll = ScrollView(a).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(20), a.dp(36), a.dp(20), a.dp(16)) }
        scroll.addView(col)
        col.addView(label(a, "HỒ SƠ CỦA TÔI", 22f, c.text, true))
        col.addView(label(a, "Trang cá nhân của chủ tài khoản", 11f, c.primary, true).apply { setPadding(0, a.dp(4), 0, a.dp(16)) })
        col.addView(msg); msg.visibility = View.GONE
        col.addView(spinner, LinearLayout.LayoutParams(a.dp(40), a.dp(40)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = a.dp(10) }); spinner.visibility = View.GONE
        col.addView(body, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        view = scroll
        a.st.profileRaw()?.let { parse(it)?.let { p -> profile = p; render() } }
    }

    fun onShow() { load() }

    private fun parse(raw: String): P? = try {
        val x = JSONObject(raw).getJSONObject("profile")
        P(x.optString("displayName"), x.optString("username"), x.optString("bio"), x.optString("contact"), x.optString("socialUrl"), x.optString("avatarUrl"), x.optLong("joinedAt"), x.optString("role", "Thành viên"), x.optString("plan"))
    } catch (e: Exception) { null }

    private fun load() {
        val s = a.st.session ?: return
        if (profile == null) spinner.visibility = View.VISIBLE
        msg.visibility = View.GONE
        a.scope.launch {
            val r = Api.profile(s, Session.deviceId(a))
            spinner.visibility = View.GONE
            when {
                r.net -> { msg.text = "Không kết nối được Server" + if (profile != null) " — đang hiển thị dữ liệu đã lưu" else ""; msg.visibility = View.VISIBLE }
                r.ok -> apply(r.json)
                else -> { msg.text = r.json.optString("error", "Không tải được hồ sơ"); msg.visibility = View.VISIBLE }
            }
        }
    }
    private fun apply(j: JSONObject) { a.st.saveProfile(j.toString()); parse(j.toString())?.let { profile = it; render() } }

    private fun planName(p: String) = when (p) { "1HOUR" -> "KEY 1 GIỜ"; "1DAY" -> "KEY 1 NGÀY"; "7DAY" -> "KEY 7 NGÀY"; "1MONTH" -> "KEY 1 THÁNG"; "1YEAR" -> "KEY 1 NĂM"; "LIFETIME" -> "KEY VĨNH VIỄN"; else -> "KEY" }

    private fun render() {
        val p = profile ?: return
        body.removeAllViews()

        // ---- Thẻ hồ sơ: ảnh bìa gradient + avatar lớn hình tròn ----
        val top = FrameLayout(a)
        val cover = View(a).apply { background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(NEON_PURPLE, Color.rgb(76, 29, 149), NEON_CYAN)).apply { cornerRadii = floatArrayOf(a.dp(26).toFloat(), a.dp(26).toFloat(), a.dp(26).toFloat(), a.dp(26).toFloat(), 0f, 0f, 0f, 0f) } }
        top.addView(cover, FrameLayout.LayoutParams(MATCH_PARENT, a.dp(104)))
        val card = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(a.dp(16), a.dp(66), a.dp(16), a.dp(18))
            background = GradientDrawable().apply { setColor(withAlpha(c.surface, 0.96f)); cornerRadius = a.dp(26).toFloat(); setStroke(a.dp(1), withAlpha(NEON_PURPLE, 0.55f)) }
        }
        val name = p.displayName.ifBlank { p.username }
        card.addView(label(a, name, 21f, c.text, true, true))
        card.addView(label(a, "@${p.username}", 12f, c.primary, true, true).apply { setPadding(0, a.dp(4), 0, a.dp(10)) })
        val badges = LinearLayout(a).apply { gravity = Gravity.CENTER }
        badges.addView(chip(p.role.uppercase(), NEON_PURPLE)); badges.addView(View(a), LinearLayout.LayoutParams(a.dp(8), 1)); badges.addView(chip(planName(p.plan), NEON_CYAN))
        card.addView(badges)
        // lớp phủ: thẻ bắt đầu từ y = 50dp để avatar nằm giữa ảnh bìa và thẻ
        val cardLp = FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = a.dp(52) }
        top.addView(card, cardLp)
        // avatar
        val ringSize = a.dp(112)
        val ring = FrameLayout(a).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(NEON_PURPLE, NEON_CYAN)).apply { shape = GradientDrawable.OVAL }
            setPadding(a.dp(4), a.dp(4), a.dp(4), a.dp(4)); elevation = a.dp(6).toFloat(); isClickable = true; setOnClickListener { a.pickAvatar() }; press()
        }
        val inner = FrameLayout(a).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c.background) }; setPadding(a.dp(3), a.dp(3), a.dp(3), a.dp(3)) }
        val av = ImageView(a).apply { scaleType = ImageView.ScaleType.CENTER_CROP }; circleClip(av)
        Images.load(p.avatarUrl, av, R.drawable.logo_default)
        inner.addView(av, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        ring.addView(inner, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        top.addView(ring, FrameLayout.LayoutParams(ringSize, ringSize).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = 0 })
        val cam = label(a, if (busyUpload) "⏳" else "📷", 14f, Color.WHITE, false, true).apply { background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(NEON_PURPLE, NEON_CYAN)).apply { shape = GradientDrawable.OVAL }; elevation = a.dp(8).toFloat() }
        top.addView(cam, FrameLayout.LayoutParams(a.dp(30), a.dp(30)).apply { gravity = Gravity.CENTER_HORIZONTAL; leftMargin = a.dp(40); topMargin = a.dp(76) })
        body.addView(top, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)); top.fadeIn()
        body.addView(View(a), LinearLayout.LayoutParams(1, a.dp(16)))

        // ---- Giới thiệu cá nhân ----
        val about = card(a, c)
        about.addView(label(a, "✦  GIỚI THIỆU CÁ NHÂN", 12f, c.primary, true)); about.addGap(a, 12)
        about.addView(infoRow("Tên chủ sở hữu", name))
        about.addView(label(a, p.bio.ifBlank { "Chưa có nội dung giới thiệu. Nhấn CHỈNH SỬA HỒ SƠ để viết đôi dòng về bạn." }, 12f, withAlpha(c.text, if (p.bio.isBlank()) 0.5f else 0.85f)).apply { setPadding(0, a.dp(6), 0, a.dp(8)) })
        if (p.contact.isNotBlank()) about.addView(infoRow("Thông tin liên hệ", p.contact))
        if (p.socialUrl.isNotBlank()) about.addView(infoRow("Mạng xã hội", p.socialUrl.removePrefix("https://"), true) { openUrl(a, p.socialUrl) })
        about.addView(infoRow("Ngày tham gia", fmtDate(p.joinedAt).substringAfter("- ")))
        about.addView(infoRow("Vai trò tài khoản", p.role))
        body.addView(about, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)); about.fadeIn(80)
        body.addView(View(a), LinearLayout.LayoutParams(1, a.dp(16)))

        // ---- Nút chức năng ----
        fun add(btn: View) { body.addView(btn, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = a.dp(10) }) }
        add(gradButton(a, "✎   CHỈNH SỬA HỒ SƠ", NEON_PURPLE, NEON_CYAN, Color.WHITE) { showEdit(p) })
        add(button(a, "💬   LIÊN HỆ ADMIN", withAlpha(c.primary, 0.14f), c.primary) { contactAdmin() })
        if (c.showSettings) add(button(a, "⚙   CÀI ĐẶT", withAlpha(c.text, 0.08f), c.text) { a.openSettings() })
        add(button(a, "⇥   ĐĂNG XUẤT", withAlpha(0xFFFF5470.toInt(), 0.14f), 0xFFFF7185.toInt()) { a.logoutKey() })
    }

    private fun chip(t: String, color: Int) = label(a, t, 10f, color, true, true).apply {
        background = roundedBg(withAlpha(color, 0.14f), a.dp(14).toFloat(), withAlpha(color, 0.5f), a.dp(1)); setPadding(a.dp(11), a.dp(5), a.dp(11), a.dp(5))
    }
    private fun infoRow(k: String, v: String, link: Boolean = false, onClick: (() -> Unit)? = null): View {
        val row = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, a.dp(5), 0, a.dp(5)) }
        row.addView(label(a, k, 11f, withAlpha(c.text, 0.55f)), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(label(a, v, 11f, if (link) c.primary else c.text, true).apply { maxWidth = a.dp(190); if (onClick != null) { setOnClickListener { onClick() }; press() } })
        return row
    }

    // ---------- Liên hệ Admin (không gọi điện): Zalo / sao chép số ----------
    private fun contactAdmin() {
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(22), a.dp(8), a.dp(22), a.dp(4)) }
        box.addView(label(a, c.contactMessage, 13f, Color.WHITE))
        if (c.contactPhone.isNotBlank()) box.addView(label(a, "Liên hệ: ${c.contactPhone}", 13f, NEON_CYAN, true).apply { setPadding(0, a.dp(10), 0, 0); setTextIsSelectable(true) })
        val b = AlertDialog.Builder(a).setTitle("Liên hệ Admin").setView(box).setNegativeButton("ĐÓNG", null)
        if (c.contactZalo.isNotBlank()) b.setPositiveButton("NHẮN ZALO") { _, _ -> openUrl(a, c.contactZalo) }
        if (c.contactPhone.isNotBlank()) b.setNeutralButton("SAO CHÉP SỐ") { _, _ ->
            (a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("admin", c.contactPhone)); a.toast("Đã sao chép")
        }
        b.show()
    }

    // ---------- Chỉnh sửa hồ sơ ----------
    private fun showEdit(p: P) {
        val dlg = Dialog(a)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val sv = ScrollView(a)
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; setPadding(a.dp(20), a.dp(20), a.dp(20), a.dp(18))
            background = GradientDrawable().apply { setColor(Color.rgb(15, 11, 34)); cornerRadius = a.dp(24).toFloat(); setStroke(a.dp(1), withAlpha(NEON_PURPLE, 0.7f)) }
        }
        sv.addView(box)
        box.addView(label(a, "CHỈNH SỬA HỒ SƠ", 16f, NEON_CYAN, true, true)); box.addGap(a, 14)
        val fName = inputField(a, "Tên hiển thị", p.displayName)
        val fUser = inputField(a, "Username (chữ thường, số, _ .)", if (p.username.matches(Regex("user[0-9]+"))) "" else p.username)
        val fBio = inputField(a, "Tiểu sử / giới thiệu bản thân", p.bio, true)
        val fContact = inputField(a, "Thông tin liên hệ", p.contact)
        val fSocial = inputField(a, "Liên kết mạng xã hội (https://...)", p.socialUrl)
        fun lab(t: String) = label(a, t, 11f, withAlpha(Color.WHITE, 0.6f), true).apply { setPadding(a.dp(2), a.dp(10), 0, a.dp(5)) }
        box.addView(lab("TÊN HIỂN THỊ")); box.addView(fName); box.addView(lab("USERNAME")); box.addView(fUser)
        box.addView(lab("TIỂU SỬ")); box.addView(fBio); box.addView(lab("LIÊN HỆ")); box.addView(fContact); box.addView(lab("MẠNG XÃ HỘI")); box.addView(fSocial)
        box.addGap(a, 10)
        box.addView(button(a, "📷   ĐỔI ẢNH ĐẠI DIỆN", withAlpha(NEON_CYAN, 0.14f), NEON_CYAN) { dlg.dismiss(); a.pickAvatar() })
        val err = label(a, "", 12f, 0xFFFF5470.toInt()).apply { setPadding(0, a.dp(10), 0, 0); visibility = View.GONE }
        box.addView(err); box.addGap(a, 12)
        val row = LinearLayout(a)
        row.addView(button(a, "HỦY", withAlpha(Color.WHITE, 0.08f), Color.WHITE) { dlg.dismiss() }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { rightMargin = a.dp(8) })
        lateinit var save: TextView
        save = gradButton(a, "LƯU", NEON_PURPLE, NEON_CYAN, Color.WHITE) {
            val s = a.st.session ?: return@gradButton
            save.text = "ĐANG LƯU..."; save.isEnabled = false; err.visibility = View.GONE
            a.scope.launch {
                val body = JSONObject().put("displayName", fName.text.toString()).put("username", fUser.text.toString()).put("bio", fBio.text.toString())
                    .put("contact", fContact.text.toString()).put("socialUrl", fSocial.text.toString())
                val r = Api.saveProfile(s, Session.deviceId(a), body)
                save.text = "LƯU"; save.isEnabled = true
                when {
                    r.net -> { err.text = "Không kết nối được Server. Thử lại."; err.visibility = View.VISIBLE }
                    r.ok -> { apply(r.json); dlg.dismiss(); a.toast("Đã lưu hồ sơ") }
                    else -> { err.text = r.json.optString("error", "Lưu thất bại"); err.visibility = View.VISIBLE }
                }
            }
        }
        row.addView(save, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        box.addView(row)
        dlg.setContentView(sv)
        dlg.window?.setLayout((a.resources.displayMetrics.widthPixels * 0.92f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dlg.show()
    }

    // ---------- Tải ảnh đại diện (đã cắt tròn) lên Server ----------
    fun uploadAvatar(file: File) {
        val s = a.st.session ?: return
        busyUpload = true; render(); a.toast("Đang tải ảnh đại diện lên...")
        a.scope.launch {
            val bytes = try { file.readBytes() } catch (e: Exception) { null }
            if (bytes == null) { busyUpload = false; render(); a.toast("Không đọc được ảnh"); return@launch }
            val r = Api.uploadAvatar(s, Session.deviceId(a), bytes)
            busyUpload = false; file.delete()
            when {
                r.net -> { render(); a.toast("Không kết nối được Server") }
                r.ok -> { apply(r.json); a.toast("Đã cập nhật ảnh đại diện") }
                else -> { render(); a.toast(r.json.optString("error", "Tải ảnh thất bại")) }
            }
        }
    }
}
