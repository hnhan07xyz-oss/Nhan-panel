
package com.fpm.panel

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import kotlin.math.roundToInt
import android.graphics.BitmapFactory
import android.widget.ImageView
import java.net.URL

private val CYAN = Color.rgb(0, 220, 255)
private val BLUE = Color.rgb(55, 105, 255)
private val PURPLE = Color.rgb(145, 75, 255)
private val DARK = Color.rgb(10, 13, 25)
private val SURFACE = Color.rgb(20, 25, 43)
private val MUTED = Color.rgb(145, 158, 185)

fun Context.dp(v: Int): Int =
    (v * resources.displayMetrics.density).roundToInt()

fun parseColor(s: String?, def: Int): Int {
    if (s.isNullOrBlank()) return def
    return try {
        Color.parseColor(if (s.startsWith("#")) s else "#$s")
    } catch (e: Exception) {
        def
    }
}

fun withAlpha(c: Int, a: Float): Int {
    return Color.argb(
        (a.coerceIn(0f, 1f) * 255).roundToInt(),
        Color.red(c),
        Color.green(c),
        Color.blue(c)
    )
}

fun roundedBg(
    fill: Int,
    radiusPx: Float,
    stroke: Int = 0,
    strokePx: Int = 0
): GradientDrawable {
    return GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusPx.coerceAtLeast(0f)
        setColor(fill)
        if (stroke != 0 && strokePx > 0) {
            setStroke(strokePx, stroke)
        }
    }
}

fun gradientBg(top: Int, bottom: Int): GradientDrawable {
    return GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(top, bottom)
    ).apply {
        shape = GradientDrawable.RECTANGLE
    }
}

fun darker(c: Int, f: Float = 0.45f): Int {
    val factor = f.coerceIn(0f, 1f)
    return Color.rgb(
        (Color.red(c) * factor).roundToInt(),
        (Color.green(c) * factor).roundToInt(),
        (Color.blue(c) * factor).roundToInt()
    )
}

fun fmtRemaining(ms: Long): String {
    if (ms <= 0) return "Đã hết hạn"

    val total = ms / 1000
    val days = total / 86400
    val hours = (total % 86400) / 3600
    val minutes = (total % 3600) / 60
    val seconds = total % 60

    return when {
        days > 0 -> "${days} ngày ${hours} giờ"
        hours > 0 -> "${hours} giờ ${minutes} phút"
        minutes > 0 -> "${minutes} phút ${seconds} giây"
        else -> "${seconds} giây"
    }
}

fun fmtDate(ms: Long?): String {
    if (ms == null || ms <= 0) return "Không xác định"

    return try {
        java.text.SimpleDateFormat(
            "HH:mm - dd/MM/yyyy",
            java.util.Locale("vi", "VN")
        ).format(java.util.Date(ms))
    } catch (e: Exception) {
        "Không xác định"
    }
}

fun View.press() {
    isClickable = true
    isFocusable = true

    setOnTouchListener { v, event ->
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                v.animate()
                    .scaleX(0.97f)
                    .scaleY(0.97f)
                    .setDuration(100)
                    .start()
            }

            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                v.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(130)
                    .start()
            }
        }
        false
    }
}

fun View.fadeIn(delay: Long = 0) {
    alpha = 0f
    translationY = 12f

    animate()
        .alpha(1f)
        .translationY(0f)
        .setStartDelay(delay)
        .setDuration(300)
        .setInterpolator(DecelerateInterpolator())
        .start()
}

fun circleClip(v: View) {
    v.background = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.TRANSPARENT)
    }
    v.clipToOutline = true
}

fun openUrl(ctx: Context, url: String) {
    try {
        val uri = Uri.parse(url.trim())
        val scheme = uri.scheme?.lowercase() ?: return

        if (scheme != "https" && scheme != "http") return

        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    } catch (_: Exception) {
    }
}

fun label(
    ctx: Context,
    text: String,
    sp: Float,
    color: Int,
    bold: Boolean = false,
    center: Boolean = false
): TextView {
    return TextView(ctx).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        typeface = if (bold) {
            Typeface.create("sans-serif", Typeface.BOLD)
        } else {
            Typeface.create("sans-serif", Typeface.NORMAL)
        }

        gravity = if (center) Gravity.CENTER else Gravity.START
        includeFontPadding = false
        setLineSpacing(ctx.dp(3).toFloat(), 1f)
    }
}

fun button(
    ctx: Context,
    text: String,
    fill: Int,
    textColor: Int,
    onClick: () -> Unit
): TextView {
    return TextView(ctx).apply {
        this.text = text
        textSize = 14f
        setTextColor(textColor)
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        gravity = Gravity.CENTER
        includeFontPadding = false

        setPadding(
            ctx.dp(18),
            ctx.dp(14),
            ctx.dp(18),
            ctx.dp(14)
        )

        background = roundedBg(
            fill,
            ctx.dp(15).toFloat(),
            withAlpha(Color.WHITE, 0.12f),
            ctx.dp(1)
        )

        setOnClickListener { onClick() }
        press()
    }
}

fun card(ctx: Context, cfg: AppConfig): LinearLayout {
    return LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL

        setPadding(
            ctx.dp(16),
            ctx.dp(15),
            ctx.dp(16),
            ctx.dp(15)
        )

        background = roundedBg(
            cfg.surface,
            ctx.dp(19).toFloat(),
            withAlpha(cfg.primary, 0.30f),
            ctx.dp(1)
        )

        elevation = ctx.dp(3).toFloat()
    }
}

fun LinearLayout.addGap(ctx: Context, h: Int) {
    addView(
        View(ctx),
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            ctx.dp(h)
        )
    )
}

class ToggleView(
    ctx: Context,
    checked: Boolean,
    accent: Int,
    onChanged: (Boolean) -> Unit
) : SwitchCompat(ctx) {

    init {
        isChecked = checked
        text = ""
        showText = false
        isClickable = true
        isFocusable = true

        thumbTintList = android.content.res.ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_checked),
                intArrayOf()
            ),
            intArrayOf(
                Color.WHITE,
                Color.rgb(190, 198, 215)
            )
        )

        trackTintList = android.content.res.ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_checked),
                intArrayOf()
            ),
            intArrayOf(
                withAlpha(accent, 0.75f),
                Color.rgb(65, 72, 90)
            )
        )

        setOnCheckedChangeListener { _, value ->
            onChanged(value)
        }
    }
}
object Images {

    fun load(
        imageUrl: String?,
        imageView: ImageView,
        fallbackRes: Int?
    ) {
        imageView.tag = imageUrl

        if (imageUrl.isNullOrBlank()) {
            if (fallbackRes != null) {
                imageView.setImageResource(fallbackRes)
            } else {
                imageView.setImageDrawable(null)
            }
            return
        }

        Thread {
            try {
                val connection = URL(imageUrl).openConnection()
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                connection.connect()

                val bitmap = connection.getInputStream().use {
                    BitmapFactory.decodeStream(it)
                }

                imageView.post {
                    if (imageView.tag == imageUrl && bitmap != null) {
                        imageView.setImageBitmap(bitmap)
                    }
                }

                connection.getInputStream().close()
            } catch (_: Exception) {
                imageView.post {
                    if (imageView.tag == imageUrl && fallbackRes != null) {
                        imageView.setImageResource(fallbackRes)
                    }
                }
            }
        }.start()
    }
}


// ====================== V3: PREMIUM (tím neon + xanh neon) ======================
val NEON_PURPLE = Color.rgb(139, 92, 246)
val NEON_CYAN = Color.rgb(34, 211, 238)

fun gradButton(ctx: Context, text: String, c1: Int, c2: Int, textColor: Int, onClick: () -> Unit): TextView {
    return TextView(ctx).apply {
        this.text = text; textSize = 14f; setTextColor(textColor)
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        gravity = Gravity.CENTER; includeFontPadding = false
        setPadding(ctx.dp(18), ctx.dp(14), ctx.dp(18), ctx.dp(14))
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply { cornerRadius = ctx.dp(15).toFloat() }
        setOnClickListener { onClick() }; press()
    }
}

fun inputField(ctx: Context, hint: String, value: String, multiline: Boolean = false): EditText {
    return EditText(ctx).apply {
        this.hint = hint; setHintTextColor(withAlpha(Color.WHITE, 0.35f)); setTextColor(Color.WHITE); textSize = 14f
        setText(value)
        setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        background = roundedBg(withAlpha(Color.WHITE, 0.06f), ctx.dp(13).toFloat(), withAlpha(NEON_PURPLE, 0.55f), ctx.dp(1))
        if (multiline) { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; minLines = 3; gravity = Gravity.TOP }
        else setSingleLine(true)
    }
}

/** Vòng xoay loading màu tím → xanh neon. */
class SpinnerView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = ctx.dp(3).toFloat() }
    private var angle = 0f
    private var anim: ValueAnimator? = null
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 900; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { angle = it.animatedValue as Float; invalidate() }; start()
        }
    }
    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(context.dp(40), context.dp(40))
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        paint.shader = SweepGradient(w / 2f, h / 2f, intArrayOf(Color.TRANSPARENT, NEON_PURPLE, NEON_CYAN), null)
    }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = cx - paint.strokeWidth
        c.save(); c.rotate(angle, cx, cy); c.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 0f, 300f, false, paint); c.restore()
    }
}

/** Icon điều hướng tự vẽ: 0 = PANEL, 1 = BOX SHARE KEY, 2 = PROFILE. */
class NavIcon(ctx: Context, private val kind: Int) : View(ctx) {
    var tint: Int = Color.GRAY
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; strokeWidth = 2f }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(context.dp(26), context.dp(26))
    override fun onDraw(c: Canvas) {
        p.color = tint
        val k = width / 24f
        c.save(); c.scale(k, k)
        when (kind) {
            0 -> {
                c.drawRoundRect(RectF(3f, 3f, 10f, 10f), 2f, 2f, p); c.drawRoundRect(RectF(14f, 3f, 21f, 10f), 2f, 2f, p)
                c.drawRoundRect(RectF(3f, 14f, 10f, 21f), 2f, 2f, p); c.drawRoundRect(RectF(14f, 14f, 21f, 21f), 2f, 2f, p)
            }
            1 -> {
                c.drawRoundRect(RectF(4f, 11f, 20f, 21f), 2f, 2f, p); c.drawRoundRect(RectF(3f, 7f, 21f, 11f), 1.5f, 1.5f, p)
                c.drawLine(12f, 7f, 12f, 21f, p)
                val bow = Path().apply {
                    moveTo(12f, 7f); cubicTo(10f, 2.5f, 6f, 3f, 7.5f, 7f)
                    moveTo(12f, 7f); cubicTo(14f, 2.5f, 18f, 3f, 16.5f, 7f)
                }
                c.drawPath(bow, p)
            }
            else -> {
                c.drawCircle(12f, 8f, 4f, p)
                val body = Path().apply { moveTo(4f, 21f); cubicTo(4f, 15f, 8f, 13f, 12f, 13f); cubicTo(16f, 13f, 20f, 15f, 20f, 21f) }
                c.drawPath(body, p)
            }
        }
        c.restore()
    }
}
