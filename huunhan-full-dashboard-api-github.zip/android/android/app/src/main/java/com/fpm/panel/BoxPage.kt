package com.fpm.panel

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Mục 2: BOX SHARE KEY — danh sách BOX do Admin quản lý, lưu cache để mở nhanh. */
class BoxPage(private val a: HomeActivity) {
    private class Box(val id: Int, val title: String, val desc: String, val logo: String, val available: Boolean, val link: String, val content: String)

    private val c = a.cfg
    private val list = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private val msg = label(a, "", 12f, 0xFFFFB020.toInt(), false, true)
    private val spinner = SpinnerView(a)
    private var shown = false
    val view: View

    init {
        val scroll = ScrollView(a).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(20), a.dp(36), a.dp(20), a.dp(16)) }
        scroll.addView(col)
        val head = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL }
        val t = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        t.addView(label(a, "BOX SHARE KEY", 22f, c.text, true)); t.addView(label(a, "Kho chia sẻ do Admin quản lý", 11f, c.primary, true).apply { setPadding(0, a.dp(4), 0, 0) })
        head.addView(t, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        head.addView(label(a, "⟳", 20f, c.primary, true, true).apply { background = roundedBg(withAlpha(c.primary, 0.14f), a.dp(14).toFloat(), withAlpha(c.primary, 0.4f), a.dp(1)); setOnClickListener { load(true) }; press() }, LinearLayout.LayoutParams(a.dp(46), a.dp(46)))
        col.addView(head); col.addGap(a, 18)
        col.addView(msg); col.addView(spinner, LinearLayout.LayoutParams(a.dp(40), a.dp(40)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = a.dp(20) })
        spinner.visibility = View.GONE; msg.visibility = View.GONE
        col.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        view = scroll
        a.st.boxesRaw()?.let { render(parse(it)) }   // hiện bản cache ngay
    }

    fun onShow() { if (!shown) { shown = true; load(false) } else load(false) }

    private fun parse(raw: String): List<Box> {
        val out = ArrayList<Box>()
        try {
            val arr = JSONObject(raw).optJSONArray("boxes") ?: return out
            for (i in 0 until arr.length()) { val x = arr.getJSONObject(i)
                out.add(Box(x.optInt("id"), x.optString("title"), x.optString("description"), x.optString("logoUrl"), x.optBoolean("available"), x.optString("link"), x.optString("content"))) }
        } catch (e: Exception) { }
        return out
    }

    private fun load(manual: Boolean) {
        val s = a.st.session ?: return
        if (list.childCount == 0) spinner.visibility = View.VISIBLE
        msg.visibility = View.GONE
        a.scope.launch {
            val r = Api.boxes(s, Session.deviceId(a))
            spinner.visibility = View.GONE
            when {
                r.net -> { msg.text = "Không kết nối được Server" + if (list.childCount > 0) " — đang hiển thị dữ liệu đã lưu" else ""; msg.visibility = View.VISIBLE }
                r.ok -> { r.json.remove("serverTime"); val raw = r.json.toString(); a.st.saveBoxes(raw); render(parse(raw)); if (manual) a.toast("Đã cập nhật danh sách BOX") }
                else -> { msg.text = r.json.optString("error", "Không tải được danh sách BOX"); msg.visibility = View.VISIBLE }
            }
        }
    }

    private fun render(boxes: List<Box>) {
        list.removeAllViews()
        if (boxes.isEmpty()) { list.addView(label(a, "Admin chưa tạo BOX nào.", 13f, withAlpha(c.text, 0.6f), false, true).apply { setPadding(0, a.dp(40), 0, 0) }); return }
        boxes.forEachIndexed { i, b -> list.addView(card(b), LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = a.dp(12) }); list.getChildAt(i).fadeIn(i * 40L) }
    }

    private fun card(b: Box): View {
        val ok = b.available
        val row = LinearLayout(a).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(a.dp(14), a.dp(14), a.dp(14), a.dp(14))
            background = if (ok) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(withAlpha(NEON_PURPLE, 0.28f), withAlpha(c.surface, 0.95f))).apply { cornerRadius = a.dp(20).toFloat(); setStroke(a.dp(1), withAlpha(NEON_PURPLE, 0.6f)) }
            else roundedBg(withAlpha(c.surface, 0.8f), a.dp(20).toFloat(), withAlpha(c.text, 0.08f), a.dp(1))
            isClickable = true; setOnClickListener { open(b) }; press()
        }
        val ring = FrameLayout(a).apply { background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(NEON_PURPLE, NEON_CYAN)).apply { shape = GradientDrawable.OVAL }; setPadding(a.dp(2), a.dp(2), a.dp(2), a.dp(2)); alpha = if (ok) 1f else 0.45f }
        if (b.logo.isNotBlank()) {
            val iv = ImageView(a).apply { scaleType = ImageView.ScaleType.CENTER_CROP }; circleClip(iv); Images.load(b.logo, iv, null)
            ring.addView(iv, FrameLayout.LayoutParams(a.dp(56), a.dp(56)))
        } else ring.addView(label(a, "🎁", 24f, Color.WHITE, false, true).apply { background = roundedBg(c.surface, a.dp(28).toFloat()) }, FrameLayout.LayoutParams(a.dp(56), a.dp(56)))
        row.addView(ring, LinearLayout.LayoutParams(a.dp(60), a.dp(60)))
        val tx = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), 0, a.dp(8), 0) }
        tx.addView(label(a, b.title, 15f, if (ok) c.text else withAlpha(c.text, 0.5f), true))
        tx.addView(label(a, if (ok) b.desc.ifBlank { "Nhấn để truy cập" } else "BOX chưa khả dụng", 11f, withAlpha(c.text, 0.6f)).apply { setPadding(0, a.dp(4), 0, 0) })
        row.addView(tx, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        row.addView(label(a, if (ok) "TRUY CẬP" else "CHƯA CÓ", 10f, if (ok) Color.WHITE else withAlpha(c.text, 0.45f), true, true).apply {
            background = if (ok) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(NEON_PURPLE, NEON_CYAN)).apply { cornerRadius = a.dp(18).toFloat() } else roundedBg(withAlpha(c.text, 0.08f), a.dp(18).toFloat())
            setPadding(a.dp(12), a.dp(8), a.dp(12), a.dp(8))
        })
        return row
    }

    private fun open(b: Box) {
        when {
            !b.available -> a.toast("BOX chưa khả dụng")
            b.link.isNotBlank() -> openUrl(a, b.link)
            else -> showContent(b)
        }
    }

    private fun showContent(b: Box) {
        val tv = label(a, b.content, 14f, Color.WHITE).apply { setTextIsSelectable(true); setPadding(a.dp(20), a.dp(8), a.dp(20), a.dp(8)) }
        AlertDialog.Builder(a).setTitle(b.title).setView(tv)
            .setPositiveButton("SAO CHÉP") { _, _ ->
                (a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("box", b.content)); a.toast("Đã sao chép")
            }.setNegativeButton("ĐÓNG", null).show()
    }
}
