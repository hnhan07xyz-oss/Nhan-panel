# HuuNhan: deploy and build

1. Upload the project contents to the repository root, preserving `android/android`, `admin`, `standalone-backend`, and `.github/workflows`.
2. In GitHub, open Actions → Build Android APK → Run workflow.
3. Download the `HuuNhan-APK` artifact after a successful run.
4. The APK build workflow uses Java 17 and Gradle 8.7; it does not require a checked-in Gradle wrapper JAR.

Backend deployment: back up `/var/lib/huunhan-api` first. Replace the deployed `server.js` with `standalone-backend/server.js`, preserve `/opt/huunhan-api/.env` and `/var/lib/huunhan-api`, then restart `huunhan-api`. Add the `/uploads/*` Caddy route in addition to the already existing `/api/*` route. Do not expose port 3002 publicly.

Do not upload `.env`, `db.json`, JWT secrets, or private signing keys to GitHub.
