# Admin Dashboard (website riêng)

Website tĩnh (`public/`) + server Node nhỏ (`server.js`, không cần `npm install`). Không có Database, không có secret; mọi thao tác đi qua Backend `/api/admin` bằng JWT admin (lưu trong `sessionStorage`, mất khi đóng tab).

## Triển khai
```bash
cd admin-dashboard && cp .env.example .env     # sửa API_URL=https://api.your-domain.com
pm2 start server.js --name fpm-admin           # hoặc: node server.js
```
Nginx + HTTPS: `deploy/nginx.conf.example`, `certbot --nginx -d admin.your-domain.com`, đặt `TRUST_PROXY=true`. Khuyến nghị giới hạn IP (Nginx `allow/deny` hoặc `DASHBOARD_IP_ALLOWLIST`).

**Bắt buộc ở Backend:** trong `backend-api/.env` đặt `ADMIN_ORIGINS=https://admin.your-domain.com` rồi restart. Nếu thiếu, trình duyệt sẽ chặn Dashboard gọi API (CORS).

Host tĩnh thay vì `server.js` (Nginx/Netlify…): sửa `public/config.js` (`API_URL`), và tự thêm header CSP/`X-Frame-Options` tương đương `server.js`.

## Đã áp dụng
CSP chỉ cho script/style cùng origin và kết nối tới API_URL · `frame-ancestors 'none'` · `noindex` + `robots.txt` · `no-store` · chặn path traversal, chỉ GET/HEAD, không lộ file ngoài `public/` · HSTS khi `TRUST_PROXY=true`.

## Kiểm thử
`tests/e2e-dashboard.js` dùng Playwright (`npm i playwright`) chạy Dashboard thật + một API giả: đăng nhập sai/đúng, hiện thống kê, request đi đúng origin API, không lỗi CSP, website lạ bị CORS chặn.
