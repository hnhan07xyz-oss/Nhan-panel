'use strict';
// Server tĩnh cho Admin Dashboard: chỉ dùng module có sẵn của Node, không chứa bí mật và không truy cập Database.
const http = require('http'); const fs = require('fs'); const path = require('path');
try { for (const l of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) { const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/); if (m && !(m[1] in process.env)) process.env[m[1]] = m[2]; } } catch {}
const PORT = +process.env.PORT || 8080;
const API_URL = (process.env.API_URL || '').trim().replace(/\/$/, '');
const TRUST = process.env.TRUST_PROXY === 'true';
const ALLOW = (process.env.DASHBOARD_IP_ALLOWLIST || '').split(',').map(x => x.trim().replace(/^::ffff:/, '')).filter(Boolean);
const ROOT = path.join(__dirname, 'public');
let apiOrigin = ''; try { apiOrigin = API_URL ? new URL(API_URL).origin : ''; } catch { console.error('API_URL không hợp lệ'); process.exit(1); }
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.txt': 'text/plain; charset=utf-8' };
const CSP = ["default-src 'self'", "script-src 'self'", "style-src 'self'", "style-src-attr 'unsafe-inline'",
  `img-src 'self' data: blob:${apiOrigin ? ' ' + apiOrigin : ''}`, `media-src 'self'${apiOrigin ? ' ' + apiOrigin : ''}`,
  `connect-src 'self'${apiOrigin ? ' ' + apiOrigin : ''}`, "object-src 'none'", "base-uri 'none'", "form-action 'self'", "frame-ancestors 'none'"].join('; ');
function headers(type, extra) {
  const h = { 'Content-Type': type, 'Content-Security-Policy': CSP, 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer', 'X-Robots-Tag': 'noindex, nofollow, noarchive', 'Cache-Control': 'no-store', 'Cross-Origin-Opener-Policy': 'same-origin', ...extra };
  if (TRUST) h['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
  return h;
}
function send(res, code, type, body) { res.writeHead(code, headers(type)); res.end(body); }
const server = http.createServer((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, TYPES['.txt'], 'Method not allowed');
  if (ALLOW.length) {
    const xf = TRUST ? String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() : '';
    const ip = (xf || req.socket.remoteAddress || '').replace(/^::ffff:/, '');
    if (!ALLOW.includes(ip)) return send(res, 404, TYPES['.txt'], 'Not found');
  }
  let p; try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch { return send(res, 400, TYPES['.txt'], 'Bad request'); }
  if (p === '/health') return send(res, 200, TYPES['.txt'], 'ok');
  if (p === '/config.js' && API_URL) return send(res, 200, TYPES['.js'], 'window.ADMIN_CONFIG = ' + JSON.stringify({ API_URL }) + ';\n');
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(ROOT, p));
  if (!file.startsWith(ROOT + path.sep) || !TYPES[path.extname(file)]) return send(res, 404, TYPES['.txt'], 'Not found');
  fs.readFile(file, (e, buf) => e ? send(res, 404, TYPES['.txt'], 'Not found') : send(res, 200, TYPES[path.extname(file)], req.method === 'HEAD' ? '' : buf));
});
server.listen(PORT, () => console.log('Admin Dashboard chạy tại cổng', PORT, apiOrigin ? '→ API ' + apiOrigin : '(chưa đặt API_URL: dùng public/config.js)'));
