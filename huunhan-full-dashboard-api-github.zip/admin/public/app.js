'use strict';
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (d) => d ? new Date(d).toLocaleString('vi-VN') : '—';
const PLANS = { '1HOUR': '1 giờ', '1DAY': '1 ngày', '7DAY': '7 ngày', '1MONTH': '1 tháng (30 ngày)', '1YEAR': '1 năm', 'LIFETIME': 'Vĩnh viễn' };
const STATUS_VI = { unused: 'CHƯA DÙNG', active: 'ĐANG HOẠT ĐỘNG', expired: 'HẾT HẠN', banned: 'BỊ KHÓA', revoked: 'THU HỒI' };
const ICONS = ['⚡', '🔥', '🎯', '🛡', '🚀', '💎', '👑', '🎮', '🎵', '☎', '⭐', '🔧', '📢', '🎁', '👁', '🧭', '💬', '📁', '✨', '🔒'];
// Dashboard là website riêng: API_URL (public/config.js) trỏ tới Backend, vd https://api.your-domain.com
const API = String((window.ADMIN_CONFIG && window.ADMIN_CONFIG.API_URL) || '').replace(/\/$/, '');
const asset = (u) => (typeof u === 'string' && u.startsWith('/uploads/')) ? API + u : u;
let token = sessionStorage.getItem('fpm_token'); let me = null; let tab = 'dash';

async function api(path, opt = {}) {
  const h = { Authorization: 'Bearer ' + token };
  if (opt.json) { h['Content-Type'] = 'application/json'; opt.body = JSON.stringify(opt.json); }
  const r = await fetch(API + '/api/admin' + path, { method: opt.method || 'GET', headers: h, body: opt.body });
  if (r.status === 401 && path !== '/login') { logout(); throw new Error('Phiên đăng nhập đã hết hạn'); }
  if (opt.raw) return r;
  const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || 'Lỗi ' + r.status); return j;
}
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2400); }
const guard = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message); } };
function modal(html) { $('#modalBody').innerHTML = html; $('#modal').classList.remove('hidden'); }
function closeModal() { $('#modal').classList.add('hidden'); }
$('#modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });
async function copy(t) { try { await navigator.clipboard.writeText(t); } catch { const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove(); } toast('Đã sao chép'); }
function download(name, text, type = 'text/plain') { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; a.click(); URL.revokeObjectURL(a.href); }
const tag = (s) => `<span class="tag t-${esc(s)}">${esc(STATUS_VI[s] || String(s).toUpperCase())}</span>`;
const sw = (attrs, on) => `<label class="sw"><input type="checkbox" ${attrs} ${on ? 'checked' : ''}><i></i></label>`;
function remaining(k, now) {
  if (k.status === 'unused') return PLANS[k.plan] + ' (chưa tính)';
  if (!k.expires_at) return k.activated_at ? 'Vĩnh viễn' : '—';
  const ms = new Date(k.expires_at).getTime() - now; if (ms <= 0) return 'Đã hết hạn';
  const s = Math.floor(ms / 1000), d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
  return (d ? d + ' ngày ' : '') + h + ' giờ ' + m + ' phút';
}

// ---------------- đăng nhập ----------------
$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault(); $('#lerr').textContent = '';
  try { const r = await api('/login', { method: 'POST', json: { username: $('#lu').value, password: $('#lp').value } }); token = r.token; sessionStorage.setItem('fpm_token', token); await boot(); }
  catch (err) { $('#lerr').textContent = err.message; }
});
function logout() { token = null; sessionStorage.removeItem('fpm_token'); $('#app').classList.add('hidden'); $('#login').classList.remove('hidden'); }
$('#logout').onclick = logout;
$('#menuBtn').onclick = () => $('#side').classList.toggle('open');
async function boot() {
  if (!token) return logout();
  try { me = await api('/me'); } catch { return logout(); }
  $('#login').classList.add('hidden'); $('#app').classList.remove('hidden'); $('#who').textContent = me.username + ' · ' + me.role; renderNav(); go(tab);
}
const TABS = [['dash', '🏠', 'Tổng quan'], ['keys', '🔑', 'Quản lý Key'], ['gen', '➕', 'Tạo Key'], ['users', '👥', 'Quản lý người dùng'], ['theme', '🎨', 'Quản lý giao diện'],
  ['brand', '🖼', 'Logo & tên ứng dụng'], ['features', '⚡', 'Chức năng Panel'], ['sections', '🗂', 'Danh mục Panel'], ['music', '🎵', 'Quản lý âm nhạc'],
  ['profile', '🧑‍💼', 'Thông tin Admin'], ['share', '🎁', 'Box Share Key Free'], ['logs', '📜', 'Nhật ký thao tác'], ['admins', '🛡', 'Quản trị viên']];
function renderNav() { $('#nav').innerHTML = TABS.filter(t => t[0] !== 'admins' || me.role === 'superadmin').map(t => `<a data-t="${t[0]}" class="${t[0] === tab ? 'on' : ''}"><span>${t[1]}</span>${t[2]}</a>`).join(''); }
$('#nav').addEventListener('click', e => { const a = e.target.closest('a'); if (a) { go(a.dataset.t); $('#side').classList.remove('open'); } });
function go(t) { tab = t; renderNav(); const f = PAGES[t]; Promise.resolve(f()).catch(e => toast(e.message)); }
const V = () => $('#view');

// ---------------- 1. Tổng quan ----------------
async function dash() {
  const s = await api('/stats');
  const c = [['🔑', 'Tổng số Key', s.total], ['🟢', 'Key đang hoạt động', s.active], ['⏳', 'Key hết hạn', s.expired], ['🆕', 'Key chưa dùng', s.unused], ['⛔', 'Key bị khóa / thu hồi', (s.banned || 0) + (s.revoked || 0)],
    ['👥', 'Tổng số người dùng', s.totalDevices], ['⚡', 'Chức năng đang bật', s.features_on + '/' + s.features_total], ['🗂', 'Danh mục đang hiển thị', s.sections_on], ['🎵', 'Bài hát đang bật', s.tracks_on]];
  V().innerHTML = '<h2>Tổng quan hệ thống</h2><div class="grid">' + c.map(x => `<div class="card stat"><i>${x[0]}</i><b>${esc(x[2] ?? 0)}</b><span>${x[1]}</span></div>`).join('') + '</div>';
}

// ---------------- 2. Quản lý Key ----------------
let kq = { q: '', status: '', plan: '', page: 1 };
async function keys() {
  V().innerHTML = `<h2>Quản lý Key</h2><div class="bar">
   <input id="kqs" placeholder="Tìm KEY / 4 ký tự cuối / ghi chú" value="${esc(kq.q)}">
   <select id="kst"><option value="">Mọi trạng thái</option>${Object.keys(STATUS_VI).map(s => `<option ${kq.status === s ? 'selected' : ''} value="${s}">${STATUS_VI[s]}</option>`).join('')}</select>
   <select id="kpl"><option value="">Mọi thời hạn</option>${Object.keys(PLANS).map(s => `<option ${kq.plan === s ? 'selected' : ''} value="${s}">${PLANS[s]}</option>`).join('')}</select>
   <button class="btn" id="kgo">Lọc</button><button class="btn primary" id="knew">+ Tạo Key</button><button class="btn" id="kexp">Xuất CSV</button></div>
   <div class="card tw"><table><thead><tr><th>Key</th><th>Loại</th><th>Trạng thái</th><th>Còn lại</th><th>Kích hoạt</th><th>Hết hạn</th><th>Thiết bị</th><th>Ghi chú</th><th></th></tr></thead><tbody id="kb"></tbody></table></div><div class="bar" style="margin-top:10px" id="kpg"></div>`;
  $('#kgo').onclick = () => { kq = { q: $('#kqs').value, status: $('#kst').value, plan: $('#kpl').value, page: 1 }; loadKeys(); };
  $('#kqs').onkeydown = e => e.key === 'Enter' && $('#kgo').click();
  $('#knew').onclick = () => go('gen'); $('#kexp').onclick = guard(exportKeys); await loadKeys();
}
const qs = () => new URLSearchParams(Object.fromEntries(Object.entries(kq).filter(([, v]) => v !== '' && v != null))).toString();
async function loadKeys() {
  const r = await api('/keys?' + qs());
  $('#kb').innerHTML = r.items.map(k => `<tr><td>••••-${esc(k.key_hint)}</td><td>${esc(PLANS[k.plan])}</td><td>${tag(k.status)}</td><td>${esc(remaining(k, r.serverTime))}</td><td>${fmt(k.activated_at)}</td>
   <td>${k.plan === 'LIFETIME' ? (k.activated_at ? 'Vĩnh viễn' : '—') : fmt(k.expires_at)}</td><td>${esc(k.device_model || (k.device_id ? '#' + k.device_id : '—'))}</td><td>${esc(k.note || '')}</td><td>${keyActions(k)}</td></tr>`).join('') || '<tr><td colspan="9">Không có Key nào</td></tr>';
  const pages = Math.max(1, Math.ceil(r.total / r.limit));
  $('#kpg').innerHTML = `<span class="muted">${r.total} key</span><button class="btn sm" ${r.page <= 1 ? 'disabled' : ''} id="pp">‹</button><span>${r.page}/${pages}</span><button class="btn sm" ${r.page >= pages ? 'disabled' : ''} id="pn">›</button>`;
  $('#pp').onclick = () => { kq.page--; loadKeys(); }; $('#pn').onclick = () => { kq.page++; loadKeys(); };
}
function keyActions(k) {
  const b = (a, l, c = '') => `<button class="btn sm ${c}" data-ka="${a}" data-id="${k.id}">${l}</button> `;
  let h = '';
  if (k.raw_status === 'banned') h += b('unban', 'Mở khóa'); else if (['unused', 'active'].includes(k.raw_status)) h += b('ban', 'Khóa');
  if (['unused', 'active'].includes(k.raw_status) && k.plan !== 'LIFETIME') h += b('extend', 'Gia hạn');
  if (k.raw_status !== 'revoked') h += b('revoke', 'Thu hồi', 'danger');
  return h + b('reset-device', 'Reset thiết bị') + b('delete', 'Xóa', 'danger');
}
async function exportKeys() { const r = await api('/keys/export?' + qs(), { raw: true }); if (!r.ok) throw new Error('Xuất thất bại'); download('keys.csv', await r.text(), 'text/csv'); }

// ---------------- 3. Tạo Key ----------------
async function gen() {
  V().innerHTML = `<h2>Tạo Key</h2><div class="card"><div class="form"><label>Thời hạn<select id="cp">${Object.entries(PLANS).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></label>
  <label>Số lượng (1 – 500)<input id="cn" type="number" min="1" max="500" value="1"></label><label class="full">Ghi chú (tùy chọn)<input id="cnote" maxlength="200"></label></div>
  <div class="row" style="margin-top:14px"><button class="btn primary" id="cgo">TẠO KEY</button></div></div><div id="gout"></div>`;
  $('#cgo').onclick = guard(async () => {
    const r = await api('/keys', { method: 'POST', json: { plan: $('#cp').value, count: +$('#cn').value, note: $('#cnote').value } });
    const list = r.keys.map(k => k.key).join('\n');
    $('#gout').innerHTML = `<div class="card" style="margin-top:14px"><h3>Đã tạo ${r.keys.length} Key (${esc(PLANS[r.keys[0].plan])})</h3><p class="err">Hãy lưu lại ngay: Key chỉ hiển thị một lần, máy chủ chỉ lưu bản mã hóa.</p><pre class="keys">${esc(list)}</pre>
    <div class="row"><button class="btn primary" id="k1">Sao chép</button><button class="btn" id="k2">Tải .txt</button><button class="btn" id="k3">Tải .csv</button></div></div>`;
    $('#k1').onclick = () => copy(list); $('#k2').onclick = () => download('keys.txt', list);
    $('#k3').onclick = () => download('keys.csv', 'key,loai\n' + r.keys.map(k => `${k.key},${k.plan}`).join('\n'), 'text/csv');
  });
}
function extendModal(id) {
  modal(`<h2>Gia hạn Key</h2><div class="form"><label class="full">Cộng thêm thời gian<select id="xp">${Object.entries(PLANS).filter(([k]) => k !== 'LIFETIME').map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></label></div>
  <div class="row" style="margin-top:14px"><button class="btn primary" id="xg">GIA HẠN</button><button class="btn ghost" id="xc">Đóng</button></div>`);
  $('#xc').onclick = closeModal;
  $('#xg').onclick = guard(async () => { await api(`/keys/${id}/extend`, { method: 'POST', json: { plan: $('#xp').value } }); closeModal(); toast('Đã gia hạn'); loadKeys(); });
}
document.addEventListener('click', guard(async (e) => {
  const b = e.target.closest('button[data-ka]'); if (!b) return;
  const { ka: a, id } = b.dataset;
  if (a === 'extend') return extendModal(id);
  if (['delete', 'revoke'].includes(a) && !confirm(a === 'delete' ? 'Xóa vĩnh viễn Key này?' : 'Thu hồi Key này? (không thể hoàn tác)')) return;
  if (a === 'delete') await api('/keys/' + id, { method: 'DELETE' }); else await api(`/keys/${id}/${a}`, { method: 'POST' });
  toast('Thành công'); loadKeys();
}));

// ---------------- 4. Người dùng ----------------
async function users() {
  V().innerHTML = `<h2>Quản lý người dùng</h2><div class="bar"><input id="uq" placeholder="Tìm theo tên máy / IP"><button class="btn" id="ug">Tìm</button></div><div class="card tw"><table><thead><tr><th>ID</th><th>Thiết bị</th><th>IP</th><th>Lần đầu</th><th>Gần nhất</th><th>Key đang dùng</th><th>Trạng thái</th><th></th></tr></thead><tbody id="ub"></tbody></table></div>`;
  $('#ug').onclick = loadUsers; $('#uq').onkeydown = e => e.key === 'Enter' && loadUsers(); await loadUsers();
}
async function loadUsers() {
  const r = await api('/devices?q=' + encodeURIComponent($('#uq').value));
  $('#ub').innerHTML = r.items.map(d => `<tr><td>${d.id}</td><td>${esc(d.model || '—')}</td><td>${esc(d.last_ip || '')}</td><td>${fmt(d.first_seen)}</td><td>${fmt(d.last_seen)}</td>
   <td>${(d.keys || []).map(k => `••${esc(k.hint)} ${esc(PLANS[k.plan])} ${tag(k.status)}`).join('<br>') || '—'}</td><td>${d.banned ? tag('banned') : tag('active')}</td>
   <td><button class="btn sm" data-h="${d.id}">Lịch sử</button> <button class="btn sm" data-d="${d.banned ? 'unban' : 'ban'}" data-id="${d.id}">${d.banned ? 'Mở khóa' : 'Khóa'}</button> <button class="btn sm" data-d="reset" data-id="${d.id}">Reset</button></td></tr>`).join('') || '<tr><td colspan="8">Chưa có người dùng</td></tr>';
}
document.addEventListener('click', guard(async (e) => {
  const d = e.target.closest('button[data-d]'); const h = e.target.closest('button[data-h]');
  if (d) { await api(`/devices/${d.dataset.id}/${d.dataset.d}`, { method: 'POST' }); toast('Thành công'); loadUsers(); }
  if (h) { const r = await api(`/devices/${h.dataset.h}/history`); modal(`<h2>Lịch sử kích hoạt</h2><div class="tw"><table><thead><tr><th>Thời gian</th><th>Sự kiện</th><th>Key</th><th>IP</th></tr></thead><tbody>${r.items.map(x => `<tr><td>${fmt(x.created_at)}</td><td>${esc(x.event)}</td><td>${x.key_hint ? '••' + esc(x.key_hint) + ' ' + esc(PLANS[x.plan]) : '—'}</td><td>${esc(x.ip)}</td></tr>`).join('') || '<tr><td colspan=4>Trống</td></tr>'}</tbody></table></div><button class="btn ghost" id="cx">Đóng</button>`); $('#cx').onclick = closeModal; }
}));

// ---------------- Form cấu hình dùng chung (giao diện / logo / thông tin Admin) ----------------
const get = (o, p) => p.split('.').reduce((a, k) => a?.[k], o);
function set(o, p, v) { const k = p.split('.'); const l = k.pop(); k.reduce((a, x) => a[x], o)[l] = v; }
function fieldHtml(c, f) {
  const v = get(c, f.p); const cls = f.full || f.t === 'area' || f.t === 'image' ? 'full' : '';
  if (f.t === 'bool') return `<label class="row ${cls}"><span class="sw"><input type="checkbox" data-p="${f.p}" ${v ? 'checked' : ''}><i></i></span> ${f.l}</label>`;
  if (f.t === 'color') return `<label>${f.l}<input type="color" data-p="${f.p}" value="${esc(v)}"></label>`;
  if (f.t === 'area') return `<label class="${cls}">${f.l}<textarea data-p="${f.p}" rows="3">${esc(v)}</textarea></label>`;
  if (f.t === 'num') return `<label>${f.l}<input type="number" step="${f.step || 1}" min="${f.min}" max="${f.max}" data-p="${f.p}" value="${esc(v)}"></label>`;
  if (f.t === 'image') return `<label class="${cls}">${f.l}<div class="row"><input data-p="${f.p}" placeholder="Dán link https hoặc bấm chọn ảnh" value="${esc(v)}" style="flex:1;min-width:150px"><input type="file" accept="image/png,image/jpeg,image/webp,image/gif" data-up="${f.p}" style="max-width:230px"></div>${v ? `<img class="thumb" src="${esc(asset(v))}" alt="">` : ''}</label>`;
  return `<label class="${cls}">${f.l}<input data-p="${f.p}" value="${esc(v)}"></label>`;
}
async function configPage(title, groups, extra) {
  const c = await api('/config');
  V().innerHTML = `<h2>${title}</h2>` + groups.map(g => `<div class="card" style="margin-bottom:14px"><h3 style="margin-top:0">${g.h}</h3><div class="form">${g.f.map(f => fieldHtml(c, f)).join('')}${g.links ? linksHtml(c) : ''}</div></div>`).join('') +
    `<div class="row"><button class="btn primary" id="tsave">LƯU THAY ĐỔI</button><button class="btn" id="tsync">ĐỒNG BỘ NGAY</button></div>` + (extra ? '<div id="extra"></div>' : '');
  const collect = () => {
    V().querySelectorAll('[data-p]').forEach(el => set(c, el.dataset.p, el.type === 'checkbox' ? el.checked : el.type === 'number' ? +el.value : el.value));
    if (V().querySelector('[data-ll]')) c.adminProfile.links = [...V().querySelectorAll('.lrow')].map(r => ({ label: r.children[0].value.trim(), url: r.children[1].value.trim() })).filter(l => l.label && l.url);
  };
  V().querySelectorAll('[data-up]').forEach(el => el.onchange = guard(async () => {
    const f = el.files[0]; if (!f) return; const fd = new FormData(); fd.append('file', f);
    const r = await api('/upload', { method: 'POST', body: fd }); const t = V().querySelector(`[data-p="${el.dataset.up}"]`); t.value = r.url; toast('Đã tải ảnh lên. Nhớ bấm LƯU THAY ĐỔI');
  }));
  $('#tsave').onclick = guard(async () => { collect(); await api('/config', { method: 'PUT', json: c }); toast('Đã lưu. Ứng dụng sẽ tự cập nhật'); go(tab); });
  $('#tsync').onclick = guard(async () => { collect(); await api('/config', { method: 'PUT', json: c }); await api('/config/sync', { method: 'POST' }); toast('Đã đồng bộ xuống ứng dụng'); go(tab); });
  return c;
}
function linksHtml(c) {
  const L = c.adminProfile.links || []; let h = '<div class="full"><label>Liên kết trang cá nhân Admin (tối đa 6: Facebook, Zalo, Telegram...)</label>';
  for (let i = 0; i < 6; i++) h += `<div class="row lrow" data-ll style="margin-top:6px"><input placeholder="Tên nút" maxlength="30" value="${esc(L[i]?.label)}" style="flex:1"><input placeholder="https://..." value="${esc(L[i]?.url)}" style="flex:2"></div>`;
  return h + '</div>';
}

// ---------------- 5. Giao diện ----------------
const pTheme = () => configPage('Quản lý giao diện', [
  { h: 'Màu sắc', f: [{ p: 'colors.primary', l: 'Màu chủ đạo', t: 'color' }, { p: 'colors.button', l: 'Màu nút', t: 'color' }, { p: 'colors.text', l: 'Màu chữ', t: 'color' }, { p: 'colors.background', l: 'Màu nền', t: 'color' }, { p: 'colors.surface', l: 'Màu khung', t: 'color' }] },
  { h: 'Ảnh nền', f: [{ p: 'backgroundUrl', l: 'Ảnh nền màn hình nhập Key', t: 'image' }, { p: 'panelBackgroundUrl', l: 'Ảnh nền Panel', t: 'image' }, { p: 'banner.url', l: 'Banner', t: 'image' }, { p: 'banner.enabled', l: 'Bật banner', t: 'bool' }] },
  { h: 'Nội dung màn hình nhập Key', f: [{ p: 'title', l: 'Tiêu đề' }, { p: 'description', l: 'Mô tả', t: 'area' }, { p: 'announcement', l: 'Thông báo trong ứng dụng', t: 'area' }, { p: 'login.title', l: 'Tiêu đề khung nhập Key' }, { p: 'login.buttonText', l: 'Chữ trên nút xác nhận' }, { p: 'login.placeholder', l: 'Gợi ý trong ô nhập Key' }, { p: 'login.description', l: 'Mô tả khung nhập Key', t: 'area' }, { p: 'expiredMessage', l: 'Thông báo khi Key hết hạn', t: 'area' }] },
  { h: 'Giao diện Panel nổi', f: [{ p: 'panel.opacity', l: 'Độ trong suốt (0.3 – 1)', t: 'num', step: 0.05, min: 0.3, max: 1 }, { p: 'panel.cornerRadius', l: 'Bo góc (0 – 40)', t: 'num', min: 0, max: 40 }, { p: 'panel.width', l: 'Chiều rộng (180 – 420)', t: 'num', min: 180, max: 420 }] },
  { h: 'Bật / tắt các mục giao diện', f: [{ p: 'toggles.showBanner', l: 'Hiện khu banner', t: 'bool' }, { p: 'toggles.showAnnouncement', l: 'Hiện thông báo', t: 'bool' }, { p: 'toggles.showSettingsButton', l: 'Hiện nút Cài đặt', t: 'bool' }, { p: 'toggles.showServerStatus', l: 'Hiện trạng thái kết nối', t: 'bool' }, { p: 'toggles.showCountdown', l: 'Hiện đồng hồ đếm ngược', t: 'bool' }] }]);
// ---------------- 6. Logo & tên ----------------
const pBrand = () => configPage('Logo & tên ứng dụng', [
  { h: 'Ứng dụng bên ngoài', f: [{ p: 'appName', l: 'Tên ứng dụng hiển thị' }, { p: 'logoUrl', l: 'Logo ứng dụng', t: 'image' }] },
  { h: 'Panel', f: [{ p: 'panel.title', l: 'Tên Panel' }, { p: 'panelIntro', l: 'Nội dung giới thiệu Panel', t: 'area' }, { p: 'panelLogoUrl', l: 'Logo Panel (logo nổi khi thu nhỏ)', t: 'image' }] }]);
// ---------------- 10. Thông tin Admin ----------------
const pProfile = () => configPage('Thông tin Admin', [
  { h: 'Trang cá nhân Admin (hiện ở màn hình nhập Key)', f: [{ p: 'adminProfile.name', l: 'Tên Admin' }, { p: 'adminProfile.avatarUrl', l: 'Ảnh đại diện', t: 'image' }, { p: 'adminProfile.bio', l: 'Giới thiệu', t: 'area' }], links: true },
  { h: 'Liên hệ Admin (mục LIÊN HỆ trong Panel)', f: [{ p: 'contact.phone', l: 'Số điện thoại (nút gọi điện)' }, { p: 'contact.zaloUrl', l: 'Link Zalo (để trống thì ẩn nút)' }, { p: 'contact.message', l: 'Nội dung hỗ trợ', t: 'area' }] }]);

// ---------------- Trình quản lý danh sách dùng chung ----------------
const ENT = {
  features: { title: 'Chức năng Panel', add: '+ Thêm chức năng', label: 'chức năng', name: 'name', icon: 'icon', sub: i => (i.description || '') + (i.action_type !== 'none' ? ' · hành động: ' + ({ link: 'mở liên kết', toast: 'hiện thông báo', call: 'gọi điện' }[i.action_type]) : ''),
    hint: 'Khi Admin TẮT chức năng, người dùng thấy nút bị khóa và Máy chủ không cho bật hay chạy.',
    fields: (sec) => [{ k: 'name', l: 'Tên chức năng', t: 'text' }, { k: 'icon', l: 'Biểu tượng', t: 'emoji' }, { k: 'description', l: 'Mô tả', t: 'area' }, { k: 'section_id', l: 'Thuộc danh mục', t: 'select', o: [['', 'Mặc định (danh mục chức năng đầu tiên)'], ...sec.filter(s => s.kind === 'features').map(s => [s.id, s.name])] },
      { k: 'action_type', l: 'Hành động khi nhấn nút (khi đã bật)', t: 'select', o: [['none', 'Không có (chỉ công tắc)'], ['link', 'Mở liên kết https'], ['toast', 'Hiện thông báo'], ['call', 'Gọi điện']] }, { k: 'action_value', l: 'Giá trị hành động (link / nội dung / số điện thoại)', t: 'text' }, { k: 'enabled', l: 'Cho phép sử dụng (Admin bật)', t: 'bool' }] },
  sections: { title: 'Danh mục Panel', add: '+ Thêm danh mục', label: 'danh mục', name: 'name', icon: 'icon', sub: i => ({ features: 'Chức năng', music: 'Âm nhạc', contact: 'Liên hệ Admin', text: 'Nội dung' }[i.kind]) + ' · thanh ' + (i.position === 'top' ? 'trên' : 'dưới') + (i.description ? ' · ' + i.description : ''),
    hint: 'Danh mục bị tắt sẽ biến mất khỏi Panel. Loại "Chức năng" hiện các chức năng, "Âm nhạc" là trình phát, "Liên hệ" là thông tin Admin, "Nội dung" hiện đoạn văn bạn viết.',
    fields: () => [{ k: 'name', l: 'Tên danh mục', t: 'text' }, { k: 'icon', l: 'Biểu tượng', t: 'emoji' }, { k: 'description', l: 'Mô tả ngắn', t: 'text' },
      { k: 'kind', l: 'Loại danh mục', t: 'select', o: [['text', 'Nội dung (văn bản)'], ['features', 'Chức năng'], ['music', 'Âm nhạc'], ['contact', 'Liên hệ Admin']] }, { k: 'position', l: 'Vị trí hiển thị', t: 'select', o: [['top', 'Thanh điều hướng phía trên'], ['bottom', 'Thanh điều hướng phía dưới']] },
      { k: 'content', l: 'Nội dung (cho loại "Nội dung")', t: 'area' }, { k: 'enabled', l: 'Hiển thị trên Panel', t: 'bool' }] },
  music: { title: 'Quản lý âm nhạc', add: '+ Thêm bài hát', label: 'bài hát', name: 'title', icon: null, sub: i => i.url,
    hint: 'Tải file MP3/M4A/OGG/WAV (tối đa 25MB) hoặc dán link https. Chỉ dùng nhạc bạn có quyền sử dụng.',
    fields: () => [{ k: 'title', l: 'Tên bài hát', t: 'text' }, { k: 'url', l: 'Đường dẫn nhạc', t: 'audio' }, { k: 'enabled', l: 'Bật bài hát', t: 'bool' }] },
  share: { title: 'Box Share Key Free', add: '+ Thêm mục chia sẻ', label: 'mục', name: 'title', icon: null, sub: i => i.content,
    hint: 'Các mục này hiển thị ở màn hình nhập Key. Bạn có thể dán Key miễn phí vào nội dung, người dùng bấm sao chép.',
    fields: () => [{ k: 'title', l: 'Tiêu đề', t: 'text' }, { k: 'content', l: 'Nội dung (có thể dán Key free)', t: 'area' }, { k: 'link', l: 'Liên kết (https, tùy chọn)', t: 'text' }, { k: 'enabled', l: 'Hiển thị', t: 'bool' }] }
};
let cur = null; let curItems = []; let curSections = [];
async function manager(key, extraTop) {
  cur = key; const e = ENT[key];
  const r = await api('/hub/' + key); curItems = r.items; if (key === 'features') curSections = (await api('/hub/sections')).items;
  V().innerHTML = `<h2>${e.title}</h2>` + (extraTop ? '<div id="extraTop"></div>' : '') + `<p class="muted" style="margin-bottom:12px">${e.hint}</p><div class="bar"><button class="btn primary" id="madd">${e.add}</button></div><div id="mlist"></div>`;
  $('#madd').onclick = () => itemForm(null);
  $('#mlist').innerHTML = curItems.map((i, n) => `<div class="item ${i.enabled ? '' : 'off'}"><div class="ic">${esc(e.icon ? i[e.icon] : (key === 'music' ? '🎵' : '🎁'))}</div>
    <div class="tx"><b>${esc(i[e.name])}</b><small>${esc(e.sub(i))}</small></div>${sw(`data-mt="${i.id}"`, i.enabled)}
    <div class="ops"><button class="btn sm" data-mv="up" data-i="${n}" ${n === 0 ? 'disabled' : ''}>▲</button><button class="btn sm" data-mv="down" data-i="${n}" ${n === curItems.length - 1 ? 'disabled' : ''}>▼</button>
    <button class="btn sm" data-me="${i.id}">Sửa</button><button class="btn sm danger" data-md="${i.id}">Xóa</button></div></div>`).join('') || `<div class="card muted">Chưa có ${e.label} nào. Bấm nút phía trên để thêm.</div>`;
}
function itemForm(item) {
  const e = ENT[cur]; const F = e.fields(curSections); const v = item || { enabled: true, icon: '⚡', kind: 'text', position: 'top', action_type: 'none', section_id: '' };
  const inp = (f) => {
    const val = v[f.k] ?? '';
    if (f.t === 'bool') return `<label class="row full"><span class="sw"><input type="checkbox" data-k="${f.k}" ${val ? 'checked' : ''}><i></i></span> ${f.l}</label>`;
    if (f.t === 'area') return `<label class="full">${f.l}<textarea data-k="${f.k}" rows="3">${esc(val)}</textarea></label>`;
    if (f.t === 'select') return `<label class="full">${f.l}<select data-k="${f.k}">${f.o.map(o => `<option value="${esc(o[0])}" ${String(val ?? '') === String(o[0]) ? 'selected' : ''}>${esc(o[1])}</option>`).join('')}</select></label>`;
    if (f.t === 'emoji') return `<label class="full">${f.l}<input data-k="${f.k}" maxlength="8" value="${esc(val)}"><div class="emoji">${ICONS.map(i => `<button type="button" data-em="${i}">${i}</button>`).join('')}</div></label>`;
    if (f.t === 'audio') return `<label class="full">${f.l}<input data-k="${f.k}" placeholder="https://... hoặc chọn file bên dưới" value="${esc(val)}"><input type="file" accept="audio/*" id="afile"></label>`;
    return `<label class="full">${f.l}<input data-k="${f.k}" value="${esc(val)}"></label>`;
  };
  modal(`<h2>${item ? 'Sửa' : 'Thêm'} ${e.label}</h2><div class="form">${F.map(inp).join('')}</div><div class="row" style="margin-top:14px"><button class="btn primary" id="isave">LƯU</button><button class="btn ghost" id="icx">Hủy</button></div>`);
  $('#icx').onclick = closeModal;
  $('#modalBody').querySelectorAll('[data-em]').forEach(b => b.onclick = () => { $('#modalBody [data-k="icon"]').value = b.dataset.em; });
  const af = $('#afile'); if (af) af.onchange = guard(async () => { const f = af.files[0]; if (!f) return; toast('Đang tải nhạc lên...'); const fd = new FormData(); fd.append('file', f); const r = await api('/upload-audio', { method: 'POST', body: fd }); $('#modalBody [data-k="url"]').value = r.url; if (!$('#modalBody [data-k="title"]').value) $('#modalBody [data-k="title"]').value = f.name.replace(/\.[^.]+$/, ''); toast('Đã tải lên'); });
  $('#isave').onclick = guard(async () => {
    const body = {}; $('#modalBody').querySelectorAll('[data-k]').forEach(el => body[el.dataset.k] = el.type === 'checkbox' ? el.checked : el.value);
    if (item) await api(`/hub/${cur}/${item.id}`, { method: 'PUT', json: body }); else await api('/hub/' + cur, { method: 'POST', json: body });
    closeModal(); toast('Đã lưu. Panel sẽ tự cập nhật'); manager(cur);
  });
}
document.addEventListener('click', guard(async (ev) => {
  const t = ev.target; if (!cur || !$('#mlist')) return;
  const me = t.closest('[data-me]'), md = t.closest('[data-md]'), mv = t.closest('[data-mv]');
  if (me) itemForm(curItems.find(i => i.id == me.dataset.me));
  if (md && confirm('Xóa vĩnh viễn?')) { await api(`/hub/${cur}/${md.dataset.md}`, { method: 'DELETE' }); toast('Đã xóa'); manager(cur); }
  if (mv) { const n = +mv.dataset.i, m = mv.dataset.mv === 'up' ? n - 1 : n + 1; const ids = curItems.map(i => i.id); [ids[n], ids[m]] = [ids[m], ids[n]]; await api(`/hub/${cur}/reorder`, { method: 'POST', json: { ids } }); manager(cur); }
}));
document.addEventListener('change', guard(async (ev) => {
  const t = ev.target.closest('[data-mt]'); if (!t || !cur) return;
  await api(`/hub/${cur}/${t.dataset.mt}`, { method: 'PUT', json: { enabled: t.checked } }); toast(t.checked ? 'Đã bật' : 'Đã tắt'); manager(cur);
}));

const pShare = async () => {
  await manager('share', true);
  const c = await api('/config');
  $('#extraTop').innerHTML = `<div class="card" style="margin-bottom:14px"><div class="form"><label class="row full"><span class="sw"><input type="checkbox" id="sbEn" ${c.shareBox.enabled ? 'checked' : ''}><i></i></span> Hiển thị Box Share Key Free ở màn hình nhập Key</label>
    <label>Tiêu đề box<input id="sbT" value="${esc(c.shareBox.title)}"></label><label>Mô tả box<input id="sbD" value="${esc(c.shareBox.description)}"></label></div><div class="row" style="margin-top:12px"><button class="btn primary" id="sbS">LƯU BOX</button></div></div>`;
  $('#sbS').onclick = guard(async () => { c.shareBox = { enabled: $('#sbEn').checked, title: $('#sbT').value, description: $('#sbD').value }; await api('/config', { method: 'PUT', json: c }); toast('Đã lưu box'); });
};

// ---------------- Nhật ký & Quản trị viên ----------------
async function logs() {
  const r = await api('/logs');
  V().innerHTML = `<h2>Nhật ký thao tác Admin</h2><div class="card tw"><table><thead><tr><th>Thời gian</th><th>Admin</th><th>Hành động</th><th>Đối tượng</th><th>Chi tiết</th><th>IP</th></tr></thead><tbody>${r.items.map(l => `<tr><td>${fmt(l.created_at)}</td><td>${esc(l.admin_name)}</td><td>${esc(l.action)}</td><td>${esc(l.target)}</td><td>${esc(l.detail)}</td><td>${esc(l.ip)}</td></tr>`).join('')}</tbody></table></div>`;
}
async function admins() {
  const r = await api('/admins');
  V().innerHTML = `<h2>Quản trị viên</h2><div class="card"><div class="form"><label>Tên đăng nhập<input id="au"></label><label>Mật khẩu (từ 10 ký tự)<input id="ap" type="password"></label><label>Quyền<select id="ar"><option value="admin">Quản trị viên</option><option value="superadmin">Quản trị tối cao</option></select></label></div><button class="btn primary" id="aadd" style="margin-top:12px">Thêm quản trị viên</button></div>
  <div class="card tw" style="margin-top:14px"><table><thead><tr><th>ID</th><th>Tên đăng nhập</th><th>Quyền</th><th>Tạo lúc</th><th></th></tr></thead><tbody>${r.items.map(a => `<tr><td>${a.id}</td><td>${esc(a.username)}</td><td>${esc(a.role)}</td><td>${fmt(a.created_at)}</td><td>${a.id === me.id ? '' : `<button class="btn sm danger" data-ad="${a.id}">Xóa</button>`}</td></tr>`).join('')}</tbody></table></div>`;
  $('#aadd').onclick = guard(async () => { await api('/admins', { method: 'POST', json: { username: $('#au').value, password: $('#ap').value, role: $('#ar').value } }); toast('Đã thêm'); admins(); });
  V().querySelectorAll('[data-ad]').forEach(b => b.onclick = guard(async () => { if (confirm('Xóa quản trị viên này?')) { await api('/admins/' + b.dataset.ad, { method: 'DELETE' }); admins(); } }));
}

const PAGES = { dash, keys, gen, users, theme: pTheme, brand: pBrand, features: () => manager('features'), sections: () => manager('sections'), music: () => manager('music'), profile: pProfile, share: pShare, logs, admins };
boot();
