// API dùng chung cho Admin Dashboard và Android APK.
window.ADMIN_CONFIG = { API_URL: 'https://huunhanpanel.duckdns.org' };
