const http = require('http'); const { spawn } = require('child_process');
const { chromium } = require('playwright');
const DASH = 'http://127.0.0.1:4100', API = 'http://127.0.0.1:4000';
const results = []; const ok = (n, c, x = '') => { results.push(c); console.log((c ? 'PASS ' : 'FAIL ') + n + (x ? '  ' + x : '')); };
const seen = [];
// API giả mô phỏng Backend: CORS chỉ cho origin của Dashboard, /api/admin yêu cầu Bearer
const api = http.createServer((req, res) => {
  seen.push(req.method + ' ' + req.url + ' origin=' + (req.headers.origin || '-'));
  const o = req.headers.origin; if (o === DASH) { res.setHeader('Access-Control-Allow-Origin', o); res.setHeader('Vary', 'Origin'); res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type'); res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE'); }
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const j = (c, b) => { res.writeHead(c, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(b)); };
  if (req.url === '/api/admin/login' && req.method === 'POST') { let b = ''; req.on('data', d => b += d); return req.on('end', () => { const x = JSON.parse(b); x.username === 'admin' && x.password === 'right-pass' ? j(200, { token: 'T' }) : j(401, { error: 'Sai tài khoản hoặc mật khẩu' }); }); }
  if (req.url.startsWith('/api/admin/')) { if (req.headers.authorization !== 'Bearer T') return j(401, { error: 'Chưa đăng nhập' });
    if (req.url === '/api/admin/me') return j(200, { id: 1, username: 'admin', role: 'superadmin' });
    if (req.url === '/api/admin/stats') return j(200, { total: 12, active: 5, expired: 2, unused: 5, banned: 0, revoked: 0, totalDevices: 4, features_on: 3, features_total: 4, sections_on: 2, tracks_on: 1 });
    return j(404, { error: 'x' }); }
  j(404, { error: 'Not found' });
});
(async () => {
  await new Promise(r => api.listen(4000, '127.0.0.1', r));
  const dash = spawn('node', ['' + require('path').join(__dirname, '..', 'server.js') + ''], { env: { ...process.env, PORT: '4100', API_URL: API }, stdio: 'inherit' });
  await new Promise(r => setTimeout(r, 800));
  const get = (u, o = {}) => fetch(u, o);
  // ---- Dashboard server
  let r = await get(DASH + '/'); ok('Dashboard phục vụ index.html', r.status === 200 && (await r.text()).includes('ADMIN'));
  const csp = r.headers.get('content-security-policy') || '';
  ok('CSP cho phép connect tới API, chặn script ngoài', csp.includes("connect-src 'self' " + API) && csp.includes("script-src 'self'") && csp.includes("frame-ancestors 'none'"));
  ok('Header noindex + no-store', /noindex/.test(r.headers.get('x-robots-tag')) && r.headers.get('cache-control') === 'no-store');
  r = await get(DASH + '/config.js'); ok('config.js sinh từ API_URL', (await r.text()).includes(API));
  r = await get(DASH + '/..%2f..%2fserver.js'); ok('Chặn path traversal', r.status === 404);
  r = await get(DASH + '/server.js'); ok('Không lộ server.js', r.status === 404);
  r = await get(DASH + '/', { method: 'POST' }); ok('Từ chối POST', r.status === 405);
  // ---- Trình duyệt
  const b = await chromium.launch(); const pg = await b.newPage(); const errs = [];
  pg.on('console', m => { if (m.type() === 'error') errs.push(m.text()); }); pg.on('pageerror', e => errs.push(String(e)));
  await pg.goto(DASH + '/'); await pg.waitForSelector('#loginForm', { state: 'visible' });
  await pg.fill('#lu', 'admin'); await pg.fill('#lp', 'sai'); await pg.click('#loginForm button');
  await pg.waitForFunction(() => document.querySelector('#lerr').textContent.length > 0);
  ok('Đăng nhập sai bị từ chối, hiện lỗi', (await pg.textContent('#lerr')).includes('Sai'));
  await pg.fill('#lp', 'right-pass'); await pg.click('#loginForm button');
  await pg.waitForSelector('#app:not(.hidden)'); await pg.waitForSelector('.stat');
  ok('Đăng nhập đúng → vào Dashboard, hiện thống kê từ API', (await pg.textContent('#who')).includes('superadmin') && (await pg.$$('.stat')).length === 9);
  ok('Mọi request admin đi tới origin API (không đi vào server Dashboard)', seen.some(s => s.startsWith('POST /api/admin/login origin=' + DASH)) && seen.some(s => s.startsWith('GET /api/admin/stats')));
  const bad = errs.filter(e => !/status of 401/.test(e)); ok('Không có lỗi CSP/JS (bỏ qua 401 do cố ý nhập sai)', bad.length === 0, bad.join(' | '));
  await pg.reload(); await pg.waitForSelector('.stat'); ok('Reload vẫn giữ phiên (sessionStorage)', true);
  // ---- Origin lạ bị CORS chặn
  const evil = http.createServer((q, s) => { s.writeHead(200, { 'Content-Type': 'text/html' }); s.end('<html><body>x</body></html>'); }); await new Promise(r => evil.listen(4200, '127.0.0.1', r));
  const p2 = await b.newPage(); await p2.goto('http://127.0.0.1:4200/');
  const blocked = await p2.evaluate(async (u) => { try { await fetch(u + '/api/admin/stats', { headers: { Authorization: 'Bearer T' } }); return false; } catch { return true; } }, API);
  ok('Website lạ không đọc được API admin (CORS)', blocked);
  await b.close(); evil.close(); dash.kill(); api.close();
  const f = results.filter(x => !x).length; console.log(f ? `\n${f} test THẤT BẠI` : `\nTất cả ${results.length} test đạt`); process.exit(f ? 1 : 0);
})();
