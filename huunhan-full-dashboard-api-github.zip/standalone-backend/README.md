# HuuNhan Standalone API

Node.js 18+ built-ins only. JSON database and media files are stored under `DATA_DIR`.

## Environment
Copy `.env.example` to `.env` and set a long `ADMIN_PASS`, random `JWT_SECRET` (at least 32 bytes), `DATA_DIR`, `PORT`, and `ADMIN_ORIGINS`. Never commit `.env` or the data directory.

## Run
`node server.js` (binds only to 127.0.0.1). Keep it behind Caddy. Add Caddy handlers for both `/api/*` and `/uploads/*` as shown in `CADDY-ROUTE.txt`.

## Supported Dashboard APIs
- Admin login, current user, stats, key CRUD/actions/export, devices and history, logs
- Persistent config read/update/sync
- Features, sections, and music CRUD/reorder/enable
- Image/audio uploads (25 MB max; image/audio MIME allowlist)
- Additional Admin accounts with role checks (passwords hashed; environment admin remains root account)

## APK APIs
- Config, key activation/status, panel sections/features/tracks, share boxes, admin profile and profile avatar upload
- Panel endpoints require a valid active key session. Feature `run` intentionally returns 501 until a specific safe action handler is implemented; arbitrary server-side commands are never executed.

## Data safety
Back up `DATA_DIR/db.json` and `DATA_DIR/uploads/` before deployment. Existing database fields are preserved; missing collections are initialized on startup.
