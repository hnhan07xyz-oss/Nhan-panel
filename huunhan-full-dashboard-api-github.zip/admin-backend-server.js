'use strict';
// Standalone HuuNhan API: Node.js built-ins only. Persistent JSON database.
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const ROOT=__dirname, DATA=process.env.DATA_DIR||path.join(ROOT,'data'), DB=path.join(DATA,'db.json');
const PORT=Number(process.env.PORT||3002), ADMIN_USER=process.env.ADMIN_USER||'admin', ADMIN_PASS=process.env.ADMIN_PASS||'';
const SECRET=process.env.JWT_SECRET||''; const ORIGIN=(process.env.ADMIN_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean);
fs.mkdirSync(DATA,{recursive:true});
const now=()=>Date.now(); const id=()=>crypto.randomUUID(); const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const defaults={version:1,rev:1,appName:'HỮU NHÂN',title:'',description:'',announcement:'',logoUrl:'',panelLogoUrl:'',backgroundUrl:'',panelBackgroundUrl:'',brandName:'',subtitle:'PREMIUM CONTROL CENTER',introTitle:'Giới thiệu',featureDesc:'',versionInfo:'',extraContent:'',panelIntro:'',expiredMessage:'KEY của bạn đã hết hạn. Vui lòng nhập KEY mới.',colors:{primary:'#22D3EE',button:'#8B5CF6',text:'#FFFFFF',background:'#07060F',surface:'#110D24'},login:{title:'KÍCH HOẠT KEY',description:'Nhập KEY được cấp để sử dụng.',placeholder:'XXXXX-XXXXX-XXXXX-XXXXX',buttonText:'XÁC NHẬN'},toggles:{showBanner:true,showAnnouncement:true,showSettingsButton:true,showServerStatus:true,showCountdown:true},banner:{enabled:false,url:''},panel:{opacity:.92,cornerRadius:18,width:300,title:'PANEL'},adminProfile:{name:'',avatarUrl:'',bio:'',links:[]},contact:{phone:'',zaloUrl:'',message:'Nếu gặp lỗi hoặc cần hỗ trợ, vui lòng liên hệ Admin.'},shareBox:{enabled:true,title:'BOX SHARE KEY FREE',description:''},shareItems:[]};
let db; try{db=JSON.parse(fs.readFileSync(DB,'utf8'))}catch{db={admins:[],keys:[],devices:[],logs:[],config:defaults,hub:{features:[],sections:[],music:[]}};save();}
function save(){const tmp=DB+'.tmp';fs.writeFileSync(tmp,JSON.stringify(db,null,2),{mode:0o600});fs.renameSync(tmp,DB)}
function json(res,code,obj,headers={}){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers});res.end(JSON.stringify(obj))}
function read(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>2e6)reject(Error('Payload too large'))});req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch{reject(Error('JSON không hợp lệ'))}});req.on('error',reject)})}
function token(payload){const b=Buffer.from(JSON.stringify(payload)).toString('base64url');const sig=crypto.createHmac('sha256',SECRET).update(b).digest('base64url');return b+'.'+sig}
function verify(t){try{const [b,s]=t.split('.');const v=crypto.createHmac('sha256',SECRET).update(b).digest('base64url');if(!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(v)))return null;const p=JSON.parse(Buffer.from(b,'base64url'));return p.exp>now()?p:null}catch{return null}}
function auth(req){const t=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');return SECRET?verify(t):null}
function log(user,action,target='',detail=''){db.logs.unshift({id:id(),created_at:new Date().toISOString(),admin_name:user||'API',action,target,detail,ip:''});db.logs=db.logs.slice(0,500);save()}
function makeKey(){const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let a=[];for(let g=0;g<4;g++){let s='';for(let i=0;i<5;i++)s+=chars[crypto.randomInt(chars.length)];a.push(s)}return a.join('-')}
const durations={ '1HOUR':3600000,'1DAY':86400000,'7DAY':604800000,'1MONTH':2592000000,'1YEAR':31536000000,'LIFETIME':0};
function status(k){if(k.status==='banned'||k.status==='revoked')return k.status;if(!k.activated_at)return 'unused';if(k.expires_at&&k.expires_at<=now())return 'expired';return 'active'}
function publicKey(k){return {id:k.id,key_hint:k.key_hint,plan:k.plan,status:status(k),raw_status:k.status==='banned'?'banned':k.status==='revoked'?'revoked':status(k),activated_at:k.activated_at?new Date(k.activated_at).toISOString():null,expires_at:k.expires_at?new Date(k.expires_at).toISOString():null,device_id:k.device_id||null,device_model:k.device_model||null,note:k.note||''}}
function sessionData(k){return {ok:true,session:k.session,plan:k.plan,status:'active',lifetime:k.plan==='LIFETIME',activatedAt:k.activated_at,expiresAt:k.expires_at||0,serverTime:now()}}
function findSession(t){return db.keys.find(k=>k.session&&k.session===t)}
const config=()=>db.config||defaults;
http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://localhost'),p=u.pathname,method=req.method;
 const origin=req.headers.origin;if(origin&&(!ORIGIN.length||ORIGIN.includes(origin))){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Authorization,Content-Type,X-Device-Id');res.setHeader('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS')}
 if(method==='OPTIONS'){res.writeHead(204);return res.end()}
 try{
 let body={};if(['POST','PUT','PATCH'].includes(method))body=await read(req);
 // APK public API
 if(p==='/api/v1/config'&&method==='GET')return json(res,200,config());
 if(p==='/api/v1/keys/activate'&&method==='POST'){
  const raw=String(body.key||'').trim().toUpperCase(),k=db.keys.find(x=>x.hash===hash(raw));if(!k)return json(res,404,{error:'KEY không tồn tại',status:'INVALID'});
  const st=status(k);if(st==='banned'||st==='revoked')return json(res,403,{error:'KEY đã bị khóa hoặc thu hồi',status:'INVALID'});if(st==='expired')return json(res,403,{error:config().expiredMessage,status:'EXPIRED'});
  const dev=String(body.deviceId||'').slice(0,160);if(k.device_id&&k.device_id!==dev)return json(res,403,{error:'KEY đã được kích hoạt trên thiết bị khác',status:'DEVICE_MISMATCH'});
  if(!k.activated_at){k.activated_at=now();k.expires_at=k.plan==='LIFETIME'?0:k.activated_at+durations[k.plan];k.device_id=dev;k.device_model=String(body.model||'Android').slice(0,120)}
  k.session=crypto.randomBytes(32).toString('hex');let d=db.devices.find(x=>x.device_id===dev);if(!d){d={id:db.devices.length+1,device_id:dev,model:k.device_model,first_seen:new Date().toISOString(),banned:false,history:[]};db.devices.push(d)}d.last_seen=new Date().toISOString();d.last_ip=req.socket.remoteAddress;d.history.unshift({created_at:new Date().toISOString(),event:'activate',key_hint:k.key_hint,plan:k.plan,ip:d.last_ip});save();return json(res,200,sessionData(k));
 }
 if(p==='/api/v1/keys/status'&&method==='POST'){
  const k=findSession((req.headers.authorization||'').replace(/^Bearer\s+/i,''));if(!k)return json(res,401,{ok:false,status:'INVALID',error:'Phiên không hợp lệ'});if(status(k)!=='active')return json(res,403,{ok:false,status:status(k).toUpperCase(),error:'KEY không còn hoạt động'});if(body.deviceId!==k.device_id)return json(res,403,{ok:false,status:'INVALID',error:'Thiết bị không khớp'});return json(res,200,sessionData(k));
 }
 // Dashboard admin API
 if(p.startsWith('/api/admin')){
  const sub=p.slice('/api/admin'.length)||'/';
  if(sub==='/login'&&method==='POST'){
   if(!ADMIN_PASS)return json(res,503,{error:'Chưa cấu hình ADMIN_PASS và JWT_SECRET trên server'});
   if(body.username!==ADMIN_USER||body.password!==ADMIN_PASS)return json(res,401,{error:'Sai tài khoản hoặc mật khẩu'});
   return json(res,200,{token:token({username:ADMIN_USER,role:'superadmin',id:1,exp:now()+12*3600000})});
  }
  const who=auth(req);if(!who)return json(res,401,{error:'Chưa đăng nhập'});
  if(sub==='/me'&&method==='GET')return json(res,200,{id:1,username:who.username,role:who.role});
  if(sub==='/stats'&&method==='GET'){const ks=db.keys.map(k=>({...k,status:status(k)}));return json(res,200,{total:ks.length,active:ks.filter(k=>k.status==='active').length,expired:ks.filter(k=>k.status==='expired').length,unused:ks.filter(k=>k.status==='unused').length,banned:ks.filter(k=>k.status==='banned').length,revoked:ks.filter(k=>k.status==='revoked').length,totalDevices:db.devices.length,features_on:0,features_total:0,sections_on:0,tracks_on:0})}
  if(sub==='/keys'&&method==='GET'){let a=db.keys.filter(k=>(!u.searchParams.get('q')||[k.key_hint,k.note].join(' ').toLowerCase().includes(u.searchParams.get('q').toLowerCase()))&&(!u.searchParams.get('status')||status(k)===u.searchParams.get('status'))&&(!u.searchParams.get('plan')||k.plan===u.searchParams.get('plan')));const page=Math.max(1,+u.searchParams.get('page')||1),limit=30;return json(res,200,{items:a.slice((page-1)*limit,page*limit).map(publicKey),total:a.length,page,limit,serverTime:now()})}
  if(sub==='/keys'&&method==='POST'){const count=Math.max(1,Math.min(500,+body.count||1)),plan=body.plan;if(!(plan in durations))return json(res,400,{error:'Thời hạn không hợp lệ'});const keys=[];for(let i=0;i<count;i++){let raw=makeKey();while(db.keys.some(k=>k.hash===hash(raw)))raw=makeKey();let k={id:id(),hash:hash(raw),key_hint:raw.slice(-4),plan,status:'unused',note:String(body.note||'').slice(0,200),created_at:now()};db.keys.push(k);keys.push({key:raw,plan})}save();log(who.username,'create_keys','',`${count} KEY ${plan}`);return json(res,201,{keys})}
  if(sub==='/keys/export'&&method==='GET'){const rows=['id,key_hint,plan,status,note',...db.keys.map(k=>[k.id,k.key_hint,k.plan,status(k),String(k.note||'').replaceAll(',',' ')].join(','))];res.writeHead(200,{'Content-Type':'text/csv; charset=utf-8'});return res.end('\ufeff'+rows.join('\n'))}
  let m=sub.match(/^\/keys\/([^/]+)(?:\/(extend|ban|unban|revoke|reset-device))?$/);if(m){let k=db.keys.find(x=>x.id===m[1]);if(!k)return json(res,404,{error:'Không tìm thấy KEY'});let act=m[2];if(method==='DELETE'&&!act){db.keys=db.keys.filter(x=>x!==k);save();return json(res,200,{ok:true})}if(method==='POST'&&act){if(act==='extend'){if(!(body.plan in durations)||body.plan==='LIFETIME')return json(res,400,{error:'Thời hạn không hợp lệ'});k.expires_at=Math.max(k.expires_at||now(),now())+durations[body.plan]}if(act==='ban')k.status='banned';if(act==='unban')k.status='active';if(act==='revoke')k.status='revoked';if(act==='reset-device'){k.device_id=null;k.device_model=null;k.session=null;k.activated_at=null;k.expires_at=null;k.status='unused'}save();return json(res,200,{ok:true})}}
  if(sub==='/config'&&method==='GET')return json(res,200,config());if(sub==='/config'&&method==='PUT'){db.config={...config(),...body,version:(config().version||0)+1,rev:(config().rev||0)+1};save();return json(res,200,{ok:true})}if(sub==='/config/sync'&&method==='POST')return json(res,200,{ok:true});
  if(sub==='/devices'&&method==='GET')return json(res,200,{items:db.devices.filter(d=>!u.searchParams.get('q')||`${d.model} ${d.last_ip}`.toLowerCase().includes(u.searchParams.get('q').toLowerCase())).map(d=>({...d,keys:db.keys.filter(k=>k.device_id===d.device_id).map(k=>({hint:k.key_hint,plan:k.plan,status:status(k)}))}))});
  m=sub.match(/^\/devices\/(\d+)\/(ban|unban|reset|history)$/);if(m){const d=db.devices.find(x=>x.id===+m[1]);if(!d)return json(res,404,{error:'Không tìm thấy thiết bị'});if(m[2]==='history')return json(res,200,{items:d.history||[]});if(m[2]==='ban'||m[2]==='unban')d.banned=m[2]==='ban';if(m[2]==='reset')db.keys.filter(k=>k.device_id===d.device_id).forEach(k=>{k.device_id=null;k.session=null;k.status='unused';k.activated_at=null;k.expires_at=null});save();return json(res,200,{ok:true})}
  if(sub==='/logs'&&method==='GET')return json(res,200,{items:db.logs});if(sub==='/admins'&&method==='GET')return json(res,200,{items:[{id:1,username:ADMIN_USER,role:'superadmin',created_at:new Date().toISOString()}]});
  if(sub.startsWith('/hub/')&&method==='GET'){const k=sub.split('/')[2];return json(res,200,{items:db.hub[k]||[]})}if(sub==='/hub/sections'&&method==='GET')return json(res,200,{items:db.hub.sections||[]});
  if(sub.startsWith('/hub/')||sub==='/upload'||sub==='/upload-audio'||sub==='/admins')return json(res,501,{error:'Chức năng này chưa được triển khai trong backend độc lập; quản lý KEY và kích hoạt APK đã sẵn sàng.'});
  return json(res,404,{error:'API admin không tồn tại'});
 }
 // APK panel endpoints: safe empty defaults; licensing remains server enforced.
 if(p==='/api/v1/panel'&&method==='GET')return json(res,200,{features:[]});
 if(p==='/api/v1/panel/boxes'&&method==='GET')return json(res,200,{items:config().shareItems||[]});
 if(p==='/api/v1/panel/profile'&&method==='GET')return json(res,200,{profile:config().adminProfile||{}});
 if(p==='/api/v1/panel/profile'&&method==='PUT')return json(res,200,{ok:true});
 if(p.startsWith('/api/v1/panel/features/'))return json(res,200,{ok:true});
 return json(res,404,{error:'Không tìm thấy API'});
 }catch(e){console.error(e);return json(res,500,{error:'Lỗi server'})}
}).listen(PORT,'127.0.0.1',()=>console.log(`HuuNhan standalone API listening on 127.0.0.1:${PORT}`));
